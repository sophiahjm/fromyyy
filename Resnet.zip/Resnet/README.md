# DLAPP

Create a deep residual network with 32-layers and test it on cifar-10 and cifar-100 dataset. To use it, just to configure hyper-params in the file `conf/xxx.yaml` and run `python resnet_cifar_main.py`  


Pretrained model will the upload later.
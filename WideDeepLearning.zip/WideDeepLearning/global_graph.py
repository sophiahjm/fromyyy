#!/usr/bin/env python
# -*- coding: utf-8 -*-
# @Time    : 17/11/13 AM10:25
# @Author  : shaoguang.csg
# @File    : global_graph.py

import tensorflow as tf

graph = tf.Graph()
# -*- coding:utf-8 -*-

import os
from functools import reduce
import io

import matplotlib.pyplot as plt
import PIL
import numpy as np
import tensorflow as tf
from tensorflow.python.framework import graph_util
# from DLAPP.models.slim.nets.vgg import vgg_16
from tensorflow.contrib.slim.nets import vgg

vgg_16 = vgg.vgg_16

dir = os.path.dirname(os.path.realpath(__file__))


def freeze_graph(model_folder, output_node_names):
    """
    freeze saved graph
    :param model_folder:
    :param output_node_names
    :return:
    """

    # We retrieve our checkpoint fullpath
    checkpoint = tf.train.get_checkpoint_state(model_folder)
    input_checkpoint = checkpoint.model_checkpoint_path

    # We precise the file fullname of our freezed graph
    absolute_model_folder = "/".join(input_checkpoint.split('/')[:-1])
    output_graph = absolute_model_folder + "/frozen_model.pb"

    # Before exporting our graph, we need to precise what is our output node
    # this variables is plural, because you can have multiple output nodes
    # freeze之前必须明确哪个是输出结点,也就是我们要得到推论结果的结点
    # 输出结点可以看我们模型的定义
    # 只有定义了输出结点,freeze才会把得到输出结点所必要的结点都保存下来,或者哪些结点可以丢弃
    # 所以,output_node_names必须根据不同的网络进行修改
    #    output_node_names = "Accuracy/predictions"

    clear_devices = True
    saver = tf.train.import_meta_graph(input_checkpoint + '.meta', clear_devices=clear_devices)
    graph = tf.get_default_graph()
    input_graph_def = graph.as_graph_def()

    # We start a session and restore the graph weights
    # 这边已经将训练好的参数加载进来,也即最后保存的模型是有图,并且图里面已经有参数了,所以才叫做是frozen
    # 相当于将参数已经固化在了图当中
    with tf.Session() as sess:
        saver.restore(sess, input_checkpoint)

        # We use a built-in TF helper to export variables to constant
        # If you have a trained graph containing Variable ops,
        # it can be convenient to convert them all to Const ops holding the same values.
        # This makes it possible to describe the network fully with a single GraphDef file,
        # and allows the removal of a lot of ops related to loading and saving the variables.
        output_graph_def = graph_util.convert_variables_to_constants(
            sess,
            input_graph_def,
            output_node_names.split(",")  # We split on comma for convenience
        )

        # Finally we serialize and dump the output graph to the filesystem
        with tf.gfile.GFile(output_graph, "wb") as f:
            f.write(output_graph_def.SerializeToString())
        print("%d ops in the final graph." % len(output_graph_def.node))


def load_graph(frozen_graph_filename):
    """
    load graph from frozen_graph_filename
    :param frozen_graph_filename:
    :return:
    """
    # We parse the graph_def file
    with tf.gfile.GFile(frozen_graph_filename, "rb") as f:
        graph_def = tf.GraphDef()
        graph_def.ParseFromString(f.read())

    # We load the graph_def in the default graph
    with tf.Graph().as_default() as graph:
        tf.import_graph_def(
            graph_def,
            input_map=None,
            return_elements=None,
            name="prefix",
            op_dict=None,
            producer_op_list=None
        )
    return graph


def load_pretrained_model(model_name, saved_checkpoint):
    batch_size = 1
    height, width = 224, 224
    num_classes = 1000
    inputs = tf.placeholder(tf.float32, shape=(None, height, width, 3))

    logits, end_points = vgg_16(inputs, num_classes)
    #    graph = tf.get_default_graph()
    saver = tf.train.Saver()
    with tf.Session() as session:
        #        session.run(tf.global_variables_initializer())
        #        W_fc7_1 = session.run(graph.get_tensor_by_name('vgg_16/fc7/weights:0'))
        #        print(W_fc7_1)

        saver.restore(session, model_name)  # load pretrained
        saver.save(session, saved_checkpoint + 'vgg_16')
        print("Model Saved: %s", model_name)


def model_statistics():
    size = lambda v: reduce(lambda x, y: x * y, v.get_shape().as_list())
    for v in tf.trainable_variables():
        print(v.name, v.device, size(v))
    print("total model size:", sum(size(v) for v in tf.trainable_variables()))


def get_shape(tensor):
    """
    get the shape of given tensor
    :param tensor:
    :return:
    """
    static_shape = tensor.shape.as_list()
    dynamic_shape = tf.unstack(tf.shape(tensor))
    dims = [s[1] if s[0] is None else s[0] for s in zip(static_shape, dynamic_shape)]
    return dims


def reshape(tensor, dims_list):
    """
    reshape tensor to given shape
    :param tensor:
    :param dims_list:
    :return:
    """
    shape = get_shape(tensor)
    dims_prod = []
    for dims in dims_list:
        if isinstance(dims, int):
            dims_prod.append(shape[dims])
        elif all([isinstance(shape[d], int) for d in dims]):
            dims_prod.append(np.prod([shape[d] for d in dims]))
        else:
            dims_prod.append(tf.reduce_prod([shape[d] for d in dims]))
    tensor = tf.reshape(tensor, dims_prod)
    return tensor


def make_parallel(fn, num_gpus, **kwargs):
    """
    Parallelize given model on multiple gpu devices.

  Args:
    fn: Arbitrary function that takes a set of input tensors and outputs a
        single tensor. First dimension of inputs and output tensor are assumed
        to be batch dimension.
    num_gpus: Number of GPU devices.
    **kwargs: Keyword arguments to be passed to the model.
  Returns:
    A tensor corresponding to the model output.
    """
    in_splits = {}
    for k, v in kwargs.items():
        in_splits[k] = tf.split(v, num_gpus)

    out_split = []
    for i in range(num_gpus):
        with tf.device(tf.DeviceSpec(device_type="GPU", device_index=i)):
            with tf.variable_scope(tf.get_variable_scope(), reuse=i > 0):
                out_split.append(fn(**{k: v[i] for k, v in in_splits.items()}))

    return tf.concat(out_split, axis=0)


def visualize_labeled_images(images, labels, max_outputs=3, name="image"):
    def _visualize_image(image, label):
        # Do the actual drawing in python
        fig = plt.figure(figsize=(3, 3), dpi=80)
        ax = fig.add_subplot(111)
        ax.imshow(image[::-1, ...])
        ax.text(0, 0, str(label),
                horizontalalignment="left",
                verticalalignment="top")
        fig.canvas.draw()

        # Write the plot as a memory file.
        buf = io.BytesIO()
        data = fig.savefig(buf, format="png")
        buf.seek(0)

        # Read the image and convert to numpy array
        img = PIL.Image.open(buf)
        return np.array(img.getdata()).reshape(img.size[0], img.size[1], -1)

    def _visualize_images(images, labels):
        # Only display the given number of examples in the batch
        outputs = []
        for i in range(max_outputs):
            output = _visualize_image(images[i], labels[i])
            outputs.append(output)
        return np.array(outputs, dtype=np.uint8)

    # Run the python op.
    figs = tf.py_func(_visualize_images, [images, labels], tf.uint8)
    return tf.summary.image(name, figs)


if __name__ == "__main__":
    model_name = "/Users/cheng/Data/pretrained_models/vgg_16/vgg_16.ckpt"
    saved_checkpoint = '/Users/cheng/Data/pretrained_models/vgg_16/vgg_checkpoint/'
    output_node_names = 'vgg_16/fc8/squeezed'

    #    load_pretrained_model(model_name, saved_checkpoint)
    freeze_graph(saved_checkpoint, output_node_names)

    #    graph = load_graph(saved_checkpoint+'frozen_model.pb')
    #    for op in graph.get_operations():
    #        print(op.name, op.values())

    #    x = graph.get_tensor_by_name("prefix/Placeholder:0")
    #    y = graph.get_tensor_by_name("prefix/vgg_16/fc8/squeezed:0")

    #    session = tf.Session(graph=graph)
    #    res = session.run(y, feed_dict={x: np.random.random((1,224,224,3)) })
    #    print(len(res[0]))

#!/usr/bin/env python
# -*- coding: utf-8 -*-
# @Time    : 18/7/10 PM8:05
# @Author  : shaoguang.csg
# @File    : test.py

import tensorflow as tf
import datetime

flags = tf.app.flags
flags.DEFINE_string("tables", "", "tables info")
flags.DEFINE_integer("task_index", None, "Worker task index")
flags.DEFINE_string("ps_hosts", "","ps hosts")
flags.DEFINE_string("worker_hosts", "", "worker hosts")
flags.DEFINE_string("job_name", None, "job name: worker or ps")

FLAGS = tf.app.flags.FLAGS


def input_fn(slice_count, slice_id):
    print("slice_count:%d, slice_id:%d" % (slice_count, slice_id))
    file_queue = tf.train.string_input_producer([FLAGS.tables], num_epochs=5)
    reader = tf.TableRecordReader(slice_count=slice_count, slice_id=slice_id)
    key, value = reader.read_up_to(file_queue, num_records=128)
    batch_values = tf.train.batch([value], batch_size=128,  capacity=64000,  enqueue_many=True)
    v1, v2, v3, v4 = tf.decode_csv(batch_values, record_defaults=[[1.0]] * 4, field_delim=',')
    labels = tf.reshape(tf.cast(v4, tf.int32), [128])
    features = tf.stack([v1, v2, v3], axis=1)

    return features, labels


#construct the model
def model_fn(features, labels, global_step):
    W = tf.Variable(tf.zeros([3, 2]))
    b = tf.Variable(tf.zeros([2]))
    pred = tf.matmul(features, W) + b

    loss =  tf.reduce_mean(tf.nn.sparse_softmax_cross_entropy_with_logits(logits=pred,labels=labels))

    # Gradient Descent
    optimizer = tf.train.GradientDescentOptimizer(0.05).minimize(loss, global_step=global_step)

    return loss, optimizer


def train(worker_count, task_index, cluster, is_chief, target):
    worker_device = "/job:worker/task:%d/cpu:0" % (task_index, 0)
    print("worker_deivce = %s" % worker_device)

    # assign io related variables and ops to local worker device
    with tf.device(worker_device):
        features, labels = input_fn(slice_count=worker_count, slice_id=task_index)

    # assign global variables to ps nodes
    available_worker_device = "/job:worker/task:%d" % (task_index)
    with tf.device(tf.train.replica_device_setter(worker_device=available_worker_device,cluster=cluster)):
        global_step = tf.Variable(0, name="global_step", trainable=False)
        # construct the model structure
        loss, optimizer = model_fn(features, labels, global_step)
        print("start training")
    hooks=[tf.train.StopAtStepHook(last_step=200000)]
    step = 0
    with tf.train.MonitoredTrainingSession(master=target, is_chief=is_chief,hooks=hooks) as mon_sess:
        while not mon_sess.should_stop():
            step = step + 1
            _, c, g = mon_sess.run([optimizer, loss, global_step])
            if step % 2000 == 0:
                print("[%s] step %d, global_step %d, loss is %f"% (datetime.datetime.now().strftime('%b-%d-%y %H:%M:%S'), step, g, c))

    print("%d steps finished." % step)


def main(unused_argv):
    print("job name = %s" % FLAGS.job_name)
    print("task index = %d" % FLAGS.task_index)
    is_chief = FLAGS.task_index == 0

    # construct the servers
    ps_spec = FLAGS.ps_hosts.split(",")
    worker_spec = FLAGS.worker_hosts.split(",")
    cluster = tf.train.ClusterSpec({"ps": ps_spec, "worker": worker_spec})
    worker_count=len(worker_spec)

    server = tf.train.Server(cluster, job_name=FLAGS.job_name, task_index=FLAGS.task_index)

    # join the ps server
    if FLAGS.job_name == "ps":
        server.join()

    # start the training
    try:
        train(worker_count=worker_count,task_index=FLAGS.task_index, cluster=cluster, is_chief=is_chief, target=server.target)
    except Exception as e:
        print("catch a exception: %s" % e.message)

if __name__=="__main__":
    import numpy as np

    c = 1
    x = c

    mapping_string = tf.constant(["emerson", "lake", "palmer", "d", 'e3', 'e33', '23e'])
    table1 = tf.contrib.lookup.index_table_from_tensor(
        mapping=mapping_string)
    words1 = tf.constant(["emerson", "lake", "palmer", "d", 'e3', 'e33', '23e'])
    ids1 = table1.lookup(words1)

    s = tf.reduce_sum(ids1)

    table2 = tf.contrib.lookup.index_to_string_table_from_tensor(
        mapping=mapping_string)
    if x > 0:
        ids2 = tf.constant([0, 1, 2, 3, 4, 5, 6], tf.int64)
        words2 = table2.lookup(ids2)

    with tf.train.MonitoredTrainingSession() as sess:
        print(sess.run(s))
        print(sess.run(ids1))
        if x > 0:
            print(sess.run(words2))





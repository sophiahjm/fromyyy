#!/usr/bin/env python
# -*- coding: utf-8 -*-
# @Time    : 18/7/4 PM4:56
# @Author  : shaoguang.csg
# @File    : prune.py

import numpy as np
import tensorflow as tf
import tensorflow.contrib.layers as layers
from tensorflow.python.ops import variable_scope
from tensorflow.python.ops import embedding_ops

from conf.prune_conf import PruneConf
from common.layers import EmbeddingLayer, DenseLayer, InputLayer
from models.basic_model import BasicModel

"""
    implement paper Preserving Proximity and Global Ranking for Network Embedding
    PRUNE：Proximity and Ranking-preserving Unsupervised Network Embedding
    and make some improvements
"""


class Prune(BasicModel):

    def __init__(self, conf, attr_size):
        super(Prune, self).__init__(conf)

        self.conf = conf
        self.attr_size = attr_size

#     def build_graph_1(self):
#         self.out_degrees = tf.placeholder(tf.float32, [None], name='out_degrees')
#         self.in_degrees = tf.placeholder(tf.float32, [None], name='in_degrees')
#
#         self.start_nodes = tf.placeholder(tf.int32, [None], name='start_nodes')
#         self.end_nodes = tf.placeholder(tf.int32, [None], name='end_nodes')
#         self.PMI = tf.placeholder(tf.float32, [None,1], name='pmi')
#
#         scope_name = 'PRUNE'
#         with tf.variable_scope(scope_name) as scope:
#             initializer = layers.xavier_initializer()
#             tf.get_variable_scope().set_initializer(initializer)
#
#             embeddings = tf.get_variable("emb", [self.attr_size['node'], self.conf.embed_size])  # lookup table
#             self.start_nodes_embed = tf.gather(embeddings, self.start_nodes)
#             self.end_nodes_embed = tf.gather(embeddings, self.end_nodes)
#
#             # W_shared
#             latent_size = self.conf.proximity_latent_size
#             w_init = np.identity(latent_size)
#             w_init += abs(np.random.randn(latent_size, latent_size) / 1000.0)
#             w_initializer = tf.constant_initializer(w_init)
#             w_shared = tf.get_variable("w_shared", [latent_size, latent_size],
#                                    initializer=w_initializer)
#             w_shared_posi = tf.nn.relu(w_shared)
#
#             head_ranking_score, head_proximity = self.forward_pass(self.start_nodes_embed, scope, self.conf.embed_size, latent_size)
#             tf.get_variable_scope().reuse_variables()
#             tail_ranking_score, tail_proximity = self.forward_pass(self.end_nodes_embed, scope, self.conf.embed_size, latent_size)
#
#             zwz = head_proximity * tf.matmul(tail_proximity, w_shared_posi)
#             zwz = tf.reduce_sum(zwz, 1, keep_dims=True)
#
#             # preserving proximity
#             self.proximity_loss = tf.reduce_mean((zwz-self.PMI)**2)
#
#             # preserving global ranking
#             r_loss = self.in_degrees * (tf.square(-tail_ranking_score/self.in_degrees + head_ranking_score/self.out_degrees))
#             self.ranking_loss = tf.reduce_mean(r_loss)
#
#             # define costs
#             self.loss = self.proximity_loss + self.conf.lambd * self.ranking_loss
#
#     def forward_pass(self, input_feature, scope, embed_size, latent_size):
#         # global node ranking score
#         w_hidden_rank = tf.get_variable("weight_hidden_rank", [embed_size, self.conf.rank_hidden_size])
#         b_hidden_rank = tf.get_variable("bias_hidden_rank", [self.conf.rank_hidden_size])
#         rank_hidden = tf.nn.elu(tf.add(tf.matmul(input_feature, w_hidden_rank), b_hidden_rank))
#
#         w_rank_output = tf.get_variable("weight_output_rank", [self.conf.rank_hidden_size, 1])
#         b_rank_output = tf.get_variable("bias_output_rank", [1])
#         ranking_score = tf.nn.softplus(tf.add(tf.matmul(rank_hidden, w_rank_output), b_rank_output))
#
#         # proximity representation
#         w_hidden_proximity = tf.get_variable("w_hidden_proximity", [embed_size, self.conf.proximity_hidden_size])
#         b_hidden_proximity = tf.get_variable("b_hidden_prox", [self.conf.proximity_hidden_size])
#         proximity_hidden = tf.nn.elu(tf.add(tf.matmul(input_feature, w_hidden_proximity), b_hidden_proximity))
#
#         w_proximity_output = tf.get_variable("w_proximity_output", [self.conf.proximity_hidden_size, self.conf.proximity_latent_size])
#         b_proximity_output = tf.get_variable("b_proximity_output", [self.conf.proximity_latent_size])
#         proximity_output = tf.nn.relu(tf.add(tf.matmul(proximity_hidden, w_proximity_output), b_proximity_output))
#
#         return ranking_score, proximity_output

    def build_graph(self):
        scope_name = 'PRUNE'
        self.start_nodes_input, self.end_nodes_input = self._build_graph_input()
        heads_ranking_score, heads_proximity = self._forward_pass(self.start_nodes_input, scope=scope_name)
        tails_ranking_score, tails_proximity = self._forward_pass(self.end_nodes_input, reuse=True, scope=scope_name)

        shared_W = self._get_shared_W(scope=scope_name)

        with variable_scope.variable_scope(scope_name):
            zWz = heads_proximity.outputs * tf.matmul(tails_proximity.outputs, shared_W)
            zWz = tf.reduce_sum(zWz, axis=1)

            # proximity loss
            self.proximity_loss = tf.reduce_mean((zWz-self.PMI)**2)

            # global node ranking loss
            ranking_loss = self.in_degrees*(tf.square(tails_ranking_score.outputs/self.in_degrees-heads_ranking_score.outputs/self.out_degrees))
            self.ranking_loss = tf.reduce_mean(ranking_loss)

            # total prune loss
            self.loss = self.proximity_loss + self.conf.lambd * self.ranking_loss
            tf.summary.scalar('proximity_loss', self.proximity_loss)
            tf.summary.scalar('ranking_loss', self.ranking_loss)

    def _get_shared_W(self, scope):
        with variable_scope.variable_scope(scope, default_name='w_shared'):
            size = self.conf.proximity_latent_size
            init = np.identity(size)
            init += abs(np.random.randn(size, size)/1000.0)
            initializer = tf.constant_initializer(init)
            shared_w = tf.get_variable('shared_w', [size, size], initializer=initializer)
            return tf.nn.relu(shared_w)

    def _forward_pass(self, input_feature, scope, reuse=None):
        with variable_scope.variable_scope(scope, default_name='forward_pass', reuse=reuse):
            input_layer = InputLayer(inputs=input_feature)

#            fused_feature = DenseLayer(input_layer, num_units=self.conf.embed_size)

            # global node ranking score
            ranking_layer = DenseLayer(
                input_layer,
                num_units=self.conf.rank_hidden_size,
                act_func=tf.nn.elu,
                w_init=layers.xavier_initializer(),
                name='ranking_layer'
            )
            ranking_score = DenseLayer(
                ranking_layer,
                num_units=1,
                act_func=tf.nn.softplus,
                w_init=layers.xavier_initializer(),
                name='ranking_score'
            )

            # proximity preserving
            proximity_layer = DenseLayer(
                input_layer,
                num_units=self.conf.proximity_hidden_size,
                act_func=tf.nn.elu,
                w_init=layers.xavier_initializer(),
                name='proximity_layer'
            )
            proximity_out = DenseLayer(
                proximity_layer,
                num_units=self.conf.proximity_latent_size,
                act_func=tf.nn.relu,
                w_init=layers.xavier_initializer(),
                name='proximity_out'
            )

            return ranking_score, proximity_out

    def _build_graph_input(self):
        num_id_cols = len(self.conf.attribute_id_cols)
        num_text_col = 1 if self.conf.attribute_text_col is not None else 0

        start_nodes_input = []
        end_nodes_input = []

        self.start_nodes = tf.placeholder(tf.int32, [None], name='start_nodes')
        self.end_nodes = tf.placeholder(tf.int32, [None], name='end_nodes')

        nodes_embedding = tf.get_variable(
            "nodes_embedding",
            shape=(self.attr_size['node'], self.conf.embed_size),
            dtype=tf.float32,
            initializer=layers.xavier_initializer(),
            trainable=True,
            partitioner=tf.min_max_variable_partitioner(
                max_partitions=self.conf.num_ps if self.conf.num_ps is not None else 1,
                min_slice_size=256 << 10
            )
        )

        self.start_nodes_embed = embedding_ops.embedding_lookup(nodes_embedding, self.start_nodes)
        end_nodes_embed = embedding_ops.embedding_lookup(nodes_embedding, self.end_nodes)

#       self.start_nodes_embed = EmbeddingLayer(
#           self.start_nodes,
#           voc_size=self.attr_size['node'],
#           embed_dim=self.conf.embed_size,
#           initializer=layers.xavier_initializer(),
#           trainable=True,
#           scope='nodes_embedding',
#           num_partition=self.conf.num_ps
#       ).outputs
#       end_nodes_embed = EmbeddingLayer(
#           self.end_nodes,
#           voc_size=self.attr_size['node'],
#           embed_dim=self.conf.embed_size,
#           initializer=layers.xavier_initializer(),
#           trainable=True,
#           scope='nodes_embedding',
#           reuse=True,
#           num_partition=self.conf.num_ps,
#       ).outputs

        start_nodes_input.append(self.start_nodes_embed)
        end_nodes_input.append(end_nodes_embed)

        self.out_degrees = tf.placeholder(tf.float32, [None], name='out_degrees')
        self.in_degrees = tf.placeholder(tf.float32, [None], name='in_degrees')

        self.PMI = tf.placeholder(tf.float32, [None], name='pmi')

        if num_id_cols > 0:
            self.start_id_attr_placeholder = {}
            self.end_id_attr_placeholder = {}
            self.start_id_attr_embed = []
            end_id_attr_embed = []
            for idx in range(num_id_cols):
                attr_name = self.conf.attribute_id_cols[idx].get('col_name')
                embed_size = self.conf.attribute_id_cols[idx].get('embed_size')
                self.start_id_attr_placeholder[attr_name] = tf.placeholder(tf.int32, [None], name=attr_name+'_start_node')
                self.end_id_attr_placeholder[attr_name] = tf.placeholder(tf.int32, [None], name=attr_name+'_end_node')
                start_id_attr_idx_embed = EmbeddingLayer(
                    self.start_id_attr_placeholder[attr_name],
                    voc_size=self.attr_size[attr_name],
                    embed_dim=embed_size,
                    trainable=True,
                    scope=attr_name+'_embedding'
                ).outputs
                end_id_attr_idx_embed = EmbeddingLayer(
                    self.end_id_attr_placeholder[attr_name],
                    voc_size=self.attr_size[attr_name],
                    embed_dim=embed_size,
                    trainable=True,
                    reuse=True,
                    scope=attr_name + '_embedding'
                ).outputs

                self.start_id_attr_embed.append(start_id_attr_idx_embed)
                end_id_attr_embed.append(end_id_attr_idx_embed)

            start_nodes_input.extend(self.start_id_attr_embed)
            end_nodes_input.extend(start_nodes_input)

        if num_text_col > 0:
            self.start_text_attr_placeholder = tf.placeholder(tf.int32, [None, None], name='start_text_attr')
            self.start_text_mask_placeholder = tf.placeholder(tf.int32, [None, None], name='start_text_mask')
            self.start_text_attr_embed = EmbeddingLayer(
                self.start_text_attr_placeholder,
                voc_size=self.attr_size['text'],
                embed_dim=self.conf.attribute_text_col.get('embed_size'),
                trainable=True,
                scope='text_embedding'
            ).outputs
            self.start_text_attr_embed = tf.multiply(self.start_text_attr_embed, self.start_text_mask_placeholder)
            self.start_text_attr_embed = tf.reduce_mean(self.start_text_attr_embed, axis=1)

            self.end_text_attr_placeholder = tf.placeholder(tf.int32, [None, None], name='end_text_attr')
            self.end_text_mask_placeholder = tf.placeholder(tf.int32, [None, None], name='end_text_mask')
            end_text_attr_embed = EmbeddingLayer(
                self.end_text_attr_placeholder,
                voc_size=self.attr_size['text'],
                embed_dim=self.conf.attribute_text_col.get('embed_size'),
                trainable=True,
                reuse=True,
                scope='text_embedding'
            ).outputs
            end_text_attr_embed = tf.multiply(end_text_attr_embed, self.end_text_mask_placeholder)
            end_text_attr_embed = tf.reduce_mean(end_text_attr_embed, axis=1)

            start_nodes_input.append(self.start_text_attr_embed)
            end_nodes_input.append(end_text_attr_embed)

        if len(start_nodes_input) > 1:
            start_nodes_input = tf.concat(start_nodes_input, axis=1)
            end_nodes_input = tf.concat(end_nodes_input, axis=1)
        else:
            start_nodes_input = start_nodes_input[0]
            end_nodes_input = end_nodes_input[0]
        return start_nodes_input, end_nodes_input

    def get_embedding(self, sess, ids):
        feed_dict = {self.start_nodes: ids}
        nodes_embed = sess.run(self.start_nodes_embed, feed_dict=feed_dict)
        return nodes_embed


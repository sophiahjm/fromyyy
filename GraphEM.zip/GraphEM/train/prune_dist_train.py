#!/usr/bin/env python
# -*- coding: utf-8 -*-
# @Time    : 18/7/10 PM8:15
# @Author  : shaoguang.csg
# @File    : dist_train.py

import tensorflow as tf
import numpy as np
import os

from utils.util import clock, count_param
from utils.logger import logger
from models.prune import Prune
from common.batch_reader import TableBatchReader
from common.table_ops import WriteEmbedding2Table
from conf.prune_conf import PruneConf
from serialization.serialization import node_attr_id_mapping, node_attr_2_idx
from common.graph_metric import link_prediction


def train(conf:PruneConf):
    is_chief = conf.task_index == 0



if __name__ == '__main__':



    conf = PruneConf()

    train(conf)
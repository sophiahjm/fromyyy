#!/usr/bin/env python
# -*- coding: utf-8 -*-
# @Time    : 18/4/28 PM5:22
# @Author  : shaoguang.csg
# @File    : test.py

import os
import sys
#import common
import tensorflow as tf
import tempfile

import pandas as pd
from pandas import DataFrame
import logging

import numpy as np

sys.path.append(os.getcwd())

CTRL_A = "\x01"

COLUMNS = ["target", "QueryOriginal", "QueryTime", "UserNettype"]
LABEL_COLUMN = "target"
CATEGORICAL_COLUMNS = ["QueryOriginal", "QueryTime", "UserNettype"]
CONTINUOUS_COLUMNS = []

logging.basicConfig(level=logging.DEBUG,
                    format='%(filename)s[line:%(lineno)d] %(levelname)s %(message)s')

logger = logging.getLogger(__name__)


def build_estimator(model_dir, model_type):
    """Build an estimator."""
    # Sparse base columns.
    # gender = tf.contrib.layers.sparse_column_with_keys(column_name="gender",
    #                                                    keys=["female", "male"])
    QueryOriginal = tf.contrib.layers.sparse_column_with_hash_bucket(
        "QueryOriginal", hash_bucket_size=10000)
    QueryTime = tf.contrib.layers.sparse_column_with_hash_bucket(
        "QueryTime", hash_bucket_size=10000)
    UserNettype = tf.contrib.layers.sparse_column_with_hash_bucket(
        "UserNettype", hash_bucket_size=10000)
    # occupation = tf.contrib.layers.sparse_column_with_hash_bucket(
    #     "occupation", hash_bucket_size=1000)
    # native_country = tf.contrib.layers.sparse_column_with_hash_bucket(
    #     "native_country", hash_bucket_size=1000)

    # Continuous base columns.
    # age = tf.contrib.layers.real_valued_column("age")
    # education_num = tf.contrib.layers.real_valued_column("education_num")
    # capital_gain = tf.contrib.layers.real_valued_column("capital_gain")
    # capital_loss = tf.contrib.layers.real_valued_column("capital_loss")
    # hours_per_week = tf.contrib.layers.real_valued_column("hours_per_week")

    # Transformations.
    # age_buckets = tf.contrib.layers.bucketized_column(age,
    #                                                   boundaries=[
    #                                                       18, 25, 30, 35, 40, 45,
    #                                                       50, 55, 60, 65
    #                                                   ])

    # Wide columns and deep columns.
    wide_columns = [QueryOriginal, QueryTime, UserNettype,
                    tf.contrib.layers.crossed_column([QueryOriginal, UserNettype],
                                                     hash_bucket_size=int(1e6))]
    deep_columns = [
    ]

    if model_type == "wide":
        m = tf.contrib.learn.LinearClassifier(model_dir=model_dir,
                                              feature_columns=wide_columns)
    elif model_type == "deep":
        m = tf.contrib.learn.DNNClassifier(model_dir=model_dir,
                                           feature_columns=deep_columns,
                                           hidden_units=[100, 50])
    else:
        m = tf.contrib.learn.DNNLinearCombinedClassifier(
            model_dir=model_dir,
            linear_feature_columns=wide_columns,
            dnn_feature_columns=deep_columns,
            dnn_hidden_units=[100, 50])
    return m


class Dataset(object):
    def __init__(self, batch_size, training_epochs, return_label=True):
        self._return_label = return_label
        self.read_op = self._create_reader(batch_size, training_epochs)
        self._init()

    def _init(self):
        gpu_options = tf.GPUOptions(allow_growth=True)
        config = tf.ConfigProto(gpu_options=gpu_options, allow_soft_placement=True,
                                log_device_placement=True)
        self.sess = tf.Session(config=config)
        init_op = [tf.global_variables_initializer(), tf.local_variables_initializer()]
        self.sess.run(init_op)

        self.coord = tf.train.Coordinator()
        self.threads = tf.train.start_queue_runners(sess=self.sess, coord=self.coord)

    def stop(self):
        self.coord.request_stop()
        self.coord.join(self.threads)
        self.sess.close()

    def _create_reader(self, batch_size, training_epochs):
        with tf.variable_scope("train_data"):
            file_name_list = ['/Users/cheng/Downloads/data_tmp/part-00000', '/Users/cheng/Downloads/data_tmp/part-00001']
            logger.info(file_name_list)
            filename_queue = tf.train.string_input_producer(file_name_list, shuffle=True, num_epochs=training_epochs)
            reader = tf.TextLineReader()
            k, v = reader.read_up_to(filename_queue, batch_size)

            cols = tf.decode_csv(v, [[""]]*4, field_delim=CTRL_A, use_quote_delim=False)
            read_op = tf.stack(cols, 1)
            return read_op

    def next_batch(self):
        try:
            df = DataFrame(self.sess.run(self.read_op), columns=COLUMNS)
            return make_tf_batch_columns(df, self._return_label)
        except Exception as e:
            logger.error(e)
            self.stop()

def make_tf_batch_columns(df, return_label):
    continuous_cols = {k: tf.constant(df[k].values) for k in CONTINUOUS_COLUMNS}
    # Creates a dictionary mapping from each categorical feature column name (k)
    # to the values of that column stored in a tf.SparseTensor.
    categorical_cols = {
        k: tf.SparseTensor(
            indices=[[i, 0] for i in range(df[k].size)],
            values=df[k].values,
            dense_shape=[df[k].size, 1])
        for k in CATEGORICAL_COLUMNS}
    # Merges the two dictionaries into one.
    feature_cols = dict(continuous_cols)
    feature_cols.update(categorical_cols)
    if return_label:
        # Converts the label column into a constant Tensor.
        label = tf.constant(df[LABEL_COLUMN].values.astype(np.float32))
        return feature_cols, label

    return feature_cols


if __name__ == "__main__":
    logger.info("Tensorflow Version:" + tf.__version__)
#    args = common.args
#    logger.info(args)

#    args.gpus = [g for g in range(int(os.getenv('GPU_NUM')))]

#    if args.model_dir == '':
#        args.model_dir = 'save/' + args.network

    logger.info("Variables initialized ...")

#    model_dir = tempfile.mkdtemp() if not args.model_dir else args.model_dir
    model_dir = tempfile.mkdtemp()
#    logger.info("model directory = %s" % args.model_dir)

    dataset = Dataset(batch_size=2048, training_epochs=1)

    m = build_estimator(model_dir, 'wide')

    logger.info("start fit")
    m.fit(input_fn=lambda: dataset.next_batch(), steps=2000) # ？？？
    logger.info("end fit")

    dataset.stop()

    logger.info('start predict')
    predict_dataset = Dataset(batch_size=2048, training_epochs=1, return_label=True)

    while True:
        fea, label = predict_dataset.next_batch()
        if fea is None:
            break
        pred_list = list(m.predict(input_fn=lambda: fea))
        logger.info(pred_list)


    logger.info("end print predict")

    from tensorflow.contrib.learn import (PredictionKey, MetricSpec)
    from tensorflow.contrib.metrics import (
        streaming_accuracy,
        streaming_auc,
        streaming_mean_absolute_error,
        streaming_precision,
        streaming_recall,
        streaming_mean_squared_error,
        streaming_root_mean_squared_error
    )

    _metrics = {
        'auc': MetricSpec(
            metric_fn=streaming_auc,
            prediction_key=PredictionKey.PROBABILITIES
        )
    }

    import tensorflow.contrib.rnn as rnn

    cell = rnn.MultiRNNCell(100)
    cell.zero_state()

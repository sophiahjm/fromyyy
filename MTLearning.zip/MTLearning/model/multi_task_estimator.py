#!/usr/bin/env python
# -*- coding: utf-8 -*-
# @Time    : 17/12/11 PM4:09
# @Author  : shaoguang.csg
# @File    : multi_task_estimator.py

import six
import tensorflow as tf
from tensorflow.contrib import layers
from tensorflow.contrib.learn.python.learn.estimators import estimator
from tensorflow.contrib.learn.python.learn.estimators import head as head_lib
from tensorflow.python.ops import nn
from tensorflow.python.ops import array_ops
from tensorflow.python.ops import partitioned_variables
from tensorflow.python.ops import variable_scope
from tensorflow.python.feature_column import feature_column as fc_core
from tensorflow.contrib.layers.python.layers import feature_column as feature_column_lib
from tensorflow.contrib.learn.python.learn.estimators import model_fn
from tensorflow.contrib.layers.python.layers import optimizers
from tensorflow.python.framework import ops
from tensorflow.contrib.learn.python.learn.estimators import prediction_key


from task.multi_task import Multitask, Task
from utils.logger import logger
from utils.tensorflow_helper import regression_head, add_hidden_layer_summary


def _get_feature_dict(features):
    if isinstance(features, dict):
        return features
    return {"": features}


def _get_optimizer(optimizer):
    if callable(optimizer):
        return optimizer()
    else:
        return optimizer


def _get_embedding_variable(column, collection_key, input_layer_scope):
    input_layer_scope = list(input_layer_scope)
    result = []
    for scope in input_layer_scope:
        result += ops.get_collection(collection_key,
                            input_layer_scope + "/" + column.name)


def _extract_embedding_lr_multipliers(
        embedding_lr_multipliers,
        collection_key,
        input_layer_scope
):
    if not embedding_lr_multipliers:
        return None
    gradient_multipliers = {}
    for column, lr_mult in embedding_lr_multipliers.items():
        if not isinstance(column, feature_column_lib._EmbeddingColumn):  # pylint: disable=protected-access
            raise ValueError(
                "learning rate multipler can only be defined for embedding columns. "
                "It is defined for {}".format(column))
        embedding = _get_embedding_variable(column, collection_key, input_layer_scope)
        if not embedding:
            raise ValueError("Couldn't find a variable for column {}".format(column))
        for v in embedding:
            gradient_multipliers[v] = lr_mult
    return gradient_multipliers


def _build_task_specific_model(features, task, net, weights_initializer, hidden_units, dropout=None, batch_norm=False, partitioner=None):
    input_layer_partitioner = partitioner  or (
        partitioned_variables.min_max_variable_partitioner(
            max_partitions=num_ps_replicas,
            min_slice_size=64 << 20
        )
    )

    task_net = None
    if task.feature_columns is not None and len(task.feature_columns) > 0:
        with variable_scope.variable_scope(
                name_or_scope='input_from_feature_columns',
                values=tuple(six.itervalues(features)),
                partitioner=input_layer_partitioner
        ) as task_input_scope:
            if all([isinstance(fc, feature_column_lib._FeatureColumn) for fc in task.feature_columns]):
                task_net = layers.input_from_feature_columns(
                    columns_to_tensors=features,
                    feature_columns=task.feature_columns,
                    weight_collections=[task.task_name, 'multi_task'],
                    scope=task_input_scope
                )
            else:
                task_net = fc_core.input_layer(
                    features=features,
                    feature_columns=task.feature_columns,
                    weight_collections=[task.task_name, 'multi_task']
                )
        for layer_id, num_hidden_units in enumerate(hidden_units):
            with variable_scope.variable_scope(
                "hidden_layer_%d" % layer_id,
                values=(task_net,)
            ) as task_hidden_layer_scope:
                task_net = layers.fully_connected( # add batch_norm
                    inputs=task_net,
                    num_outputs=num_hidden_units,
                    activation_fn=tf.identity,
                    variables_collections=[task.task_name, 'multi_task'],
                    scope=task_hidden_layer_scope,
                    weights_initializer=weights_initializer
                )

                if batch_norm:
                    pass # TODO
                task_net = activation_fn(task_net)

                if dropout is not None and mode == model_fn.ModeKeys.TRAIN:
                    task_net = layers.dropout(task_net, keep_prob=(1.0-dropout))
            add_hidden_layer_summary(task_net, task_hidden_layer_scope.name)

    task_net = tf.concat([task_net, net], axis=1, name=task.task_name+'_concat') if task_net is not None else net
    for layer_id, num_hidden_units in enumerate(task.hidden_units):
        with variable_scope.variable_scope(
            "merge_hidden_layer_%d" % layer_id,
            values=(task_net,)
        ) as task_hidden_layer_scope:
            task_net = layers.fully_connected( # add batch_norm
                inputs=task_net,
                num_outputs=num_hidden_units,
                activation_fn=tf.identity,
                variables_collections=[task.task_name, 'multi_task'],
                scope=task_hidden_layer_scope,
                weights_initializer=weights_initializer
            )

            if batch_norm:
                pass  # TODO
            task_net = activation_fn(task_net)

            if dropout is not None and mode == model_fn.ModeKeys.TRAIN:
                task_net = layers.dropout(task_net, keep_prob=(1.0 - dropout))
        add_hidden_layer_summary(task_net, task_hidden_layer_scope.name)
    return task_net


def multi_task_model_fn(features, labels, mode, params, config=None):
    """
    define muti-task learning model structure
    :param features: `Tensor` or dict of `Tensor` (depends on data passed to `fit`).
    :param labels: `Tensor` of shape [batch_size, 1] or [batch_size] labels of dtype
      `int32` or `int64` in the range `[0, n_classes)`.
    :param mode: Defines whether this is training, evaluation or prediction.
      See `ModeKeys`.
    :param params: A dict of hyperparameters
    :param config: `RunConfig` object to configure the runtime settings.
    :return:
    """
    multi_tasks = params['multi_tasks'] # parse variables fro params
    head = params['head']
    feature_columns = params['feature_columns']
    optimizer = params['optimizer']
    learning_rate = params['learning_rate']
    activation_fn = params['activation_fn']
    dropout = params['dropout']
    batch_norm = params['batch_norm']
    beta = params['beta']
    gradient_clip_norm = params['gradient_clip_norm']
    learning_rate_decay_fn = params['learning_rate_decay_fn']
    weights_initializer = params['weights_initializer']
    num_ps_replicas = config.num_ps_replicas if config else 0
    input_layer_partitioner = params.get('input_layer_partitioner')  or (
        partitioned_variables.min_max_variable_partitioner(
            max_partitions=num_ps_replicas,
            min_slice_size=64 << 20
        )
    )
    embedding_lr_multipliers = params.get("embedding_lr_multipliers", {})

    if not feature_columns:
        raise ValueError('feature_columns must be defined')

    features = _get_feature_dict(features)
    optimizer = _get_optimizer(optimizer)

    # build multi-task common part
    if not multi_tasks.common_hidden_units:
        raise ValueError("common_hidden_units must be defined")
    if not multi_tasks.common_feature_columns:
        raise ValueError("common_feature_columns must be defined")
    partitioner = (
        partitioned_variables.min_max_variable_partitioner(
            max_partitions=num_ps_replicas
        )
    )
    with variable_scope.variable_scope(
        name_or_scope='multi_task',
        values=tuple(six.itervalues(features)),
        partitioner=partitioner
    ) as multi_task_scope:
        with variable_scope.variable_scope(
            name_or_scope='input_from_feature_columns',
            values=tuple(six.itervalues(features)),
            partitioner=input_layer_partitioner
        ) as multi_task_input_scope:
            if all([isinstance(fc, feature_column_lib._FeatureColumn) for fc in multi_tasks.common_feature_columns]):
                net = layers.input_from_feature_columns(
                    columns_to_tensors=features,
                    feature_columns=multi_tasks.common_feature_columns,
                    weight_collections=['common_part', 'multi_task'],
                    scope=multi_task_input_scope
                )
            else:
                net = fc_core.input_layer(
                    features=features,
                    feature_columns=multi_tasks.common_feature_columns,
                    weight_collections=['common_part', 'multi_task']
                )

        # build common part body
        for layer_id, num_hidden_units in enumerate(multi_tasks.common_hidden_units):
            with variable_scope.variable_scope(
                "hidden_layer_%d" % layer_id,
                values=(net,)
            ) as multi_task_common_layer_scope:
                net = layers.fully_connected(
                    inputs=net,
                    num_outputs=num_hidden_units,
                    activation_fn=tf.identity,
                    variables_collections=['common_part', 'multi_task'],
                    scope=multi_task_common_layer_scope,
                    weights_initializer=weights_initializer
                )

                if batch_norm:
                    pass # TODO
                net = activation_fn(net)

                if dropout is not None and mode == model_fn.ModeKeys.TRAIN:
                    net = layers.dropout(net, keep_prob=(1.0-dropout))
            add_hidden_layer_summary(net, multi_task_common_layer_scope.name)

        logits = {}
        # build task-specific part
        for task_id, (task_name, task) in multi_tasks.get_tasks().items():
            with variable_scope.variable_scope(
                name_or_scope=task_name,
                values=tuple(six.itervalues(features))
            ) as task_specific_scope:
                task_net = _build_task_specific_model(
                    features,
                    task,
                    net,
                    weights_initializer,
                    multi_tasks.common_hidden_units,
                    dropout,
                    batch_norm,
                    input_layer_partitioner
                )
                task_head = head._heads[task_id]
                with variable_scope.variable_scope(
                        name_or_scope=task_name+'_logits',
                        values=(task_net,)) as task_specific_logits_scope:
                    task_logits = layers.fully_connected(
                        net,
                        task_head.logits_dimension,
                        activation_fn=None,
                        variables_collections=[task_name, 'multi_task'],
                        scope=task_specific_logits_scope,
                        weights_initializer=weights_initializer
                    )
                _add_hidden_layer_summary(task_logits, task_specific_logits_scope.name)
                logits[task_head.head_name] = task_logits

    def _make_training_op(training_loss):
        input_layer_scope = [multi_task_input_scope.name]
        for task in multi_tasks.get_tasks():
            input_layer_scope.append('multi_task/'+task.task_name+'/input_from_feature_columns')

        if beta > 0.0: # add l2 norm
            vars = tf.trainable_variables(scope=multi_task_scope)
            l2_loss = [tf.nn.l2_loss(var) for var in vars if var.op.name.find(r'kernel') > 0]
            training_loss += beta*tf.add_n(l2_loss)

        return optimizers.optimize_loss(
            loss=training_loss,
            global_step=tf.train.get_global_step(),
            learning_rate=learning_rate,
            optimizer=_get_optimizer(optimizer),
            gradient_multipliers=_extract_embedding_lr_multipliers(
                embedding_lr_multipliers,
                'multi-task',
                input_layer_scope
            ),
            clip_gradients=gradient_clip_norm,
            learning_rate_decay_fn=learning_rate_decay_fn,
            variables=None,
            name='multi-task',
            summaries=[],
            increment_global_step=True
        )

    return head.create_model_fn_ops(
        features=features,
        mode=mode,
        labels=labels,
        train_op_fn=_make_training_op,
        logits=logits
    )


class MultiTaskEstimator(estimator.Estimator):
    """
    An Estimator for multi-task joined training models

    for each column in `feature_columns`:
    - if `column` is a `SparseColumn`, a feature with `key=column.name`
      whose `value` is a `SparseTensor`.
    - if `column` is a `WeightedSparseColumn`, two features: the first with
      `key` the id column name, the second with `key` the weight column name.
      Both features' `value` must be a `SparseTensor`.
    - if `column` is a `RealValuedColumn`, a feature with `key=column.name`
      whose `value` is a `Tensor`.
    """
    def __init__(self,
                 multi_tasks: Multitask,
                 model_dir=None,
                 weight_column_name=None,
                 optimizer=None,
                 learning_rate=0.01,
                 activation_fn=nn.relu,
                 dropout=None,
                 batch_norm=False,
                 beta=0.0,
                 gradient_clip_norm=None,
                 enable_centered_bias=False,
                 config=None,
                 feature_engineering_fn=None,
                 embedding_lr_multipliers=None,
                 input_layer_min_slice_size=None,
                 label_keys:dict=None,
                 learning_rate_decay_fn=None,
                 weights_initializer=layers.xavier_initializer()
                 ):
        """
        Initializes a MultiTaskEstimator instance.
        :param multi_tasks: multi-task learning structure，Multi-task
        :param model_dir: Directory to save model parameters, graph and etc. This can
        also be used to load checkpoints from the directory into a estimator to
        continue training a previously saved model.
        :param weight_column_name: A string defining feature column name representing
        weights. It is used to down weight or boost examples during training. It
        will be multiplied by the loss of the example.
        :param optimizer: An instance of `tf.Optimizer` used to train the model. If
        `None`, will use an Adagrad optimizer.
        :param activation_fn: Activation function applied to each layer. If `None`, will
        use tf.nn.relu. Note that a string containing the unqualified
        name of the op may also be provided, e.g., "relu", "tanh", or "sigmoid".
        :param dropout
        :param batch_norm
        :param beta coefficient for l2 norm, default 0
        :param gradient_clip_norm: A float > 0. If provided, gradients are
        clipped to their global norm with this clipping ratio. See
        `tf.clip_by_global_norm` for more details.
        :param enable_centered_bias:  A bool. If True, estimator will learn a centered
        bias variable for each class. Rest of the model structure learns the
        residual after centered bias.
        :param config: `RunConfig` object to configure the runtime settings.
        :param feature_engineering_fn: Feature engineering function. Takes features and
        labels which are the output of `input_fn` and returns features and
        labels which will be fed into the model.
        :param embedding_lr_multipliers: Optional. A dictionary from `EmbeddingColumn` to
        a `float` multiplier. Multiplier will be used to multiply with learning
        rate for the embedding variables.
        :param input_layer_min_slice_size: The min slice size of input layer
        partitions. If not provided, will use the default of 64M.
        label_keys: Optional dict from task_name to strings defining the
        label vocabulary. Only supported for `n_classes` > 2. only work for classification task_type
        learning_rate_decay_fn: function type learning_rate_decay_fn(lr, global_step)
        weights_initializer:
        Returns:
        A `MultiTaskEstimator`.
        """
        self._multi_tasks = multi_tasks

        heads = [] # create head for each task in multi_tasks
        loss_weights = [] # loss weight for each task
        self._feature_columns = dict()
        self._feature_columns['common_feature_columns'] = tuple(self._multi_tasks.common_feature_columns or [])
        for task_name, task in self._multi_tasks.get_tasks().items():
            _label_keys = None if label_keys is None else label_keys.get(task_name, None)
            loss_weights.append(1.0 if task.weight is None else task.weight)
            self._feature_columns[task_name+'_feature_columns'] = tuple(task.feature_columns or [])
            if task.task_type == 'classification':
                head = head_lib.multi_class_head(
                    n_classes=task.num_class,
                    weight_column_name=weight_column_name,
                    enable_centered_bias=enable_centered_bias,
                    head_name=task_name+'_head',
                    thresholds=[0.5],
                    loss_fn=head_lib._softmax_cross_entropy_loss if task.loss_fn is None else task.loss_fn,
                    label_keys=_label_keys
                )
            elif task.task_type == 'regression':
                head = regression_head(
                    label_name=_label_keys,
                    weight_column_name=weight_column_name,
                    enable_centered_bias=enable_centered_bias,
                    head_name=task_name+'_head',
                    loss_fn=head_lib._mean_squared_loss if task.loss_fn is None else task.loss_fn,
                    link_fn=array_ops.identity
                )
            else:
                logger.error("Unsupported task type")
                raise TypeError
            heads.append(head)
        self._multi_head = head_lib.multi_head(heads=heads, loss_weights=loss_weights)

        input_layer_partitioner = None
        if input_layer_min_slice_size is not None:
            input_layer_partitioner = (
                partitioned_variables.min_max_variable_partitioner(
                    max_partitions=config.num_ps_replicas if config else 0,
                    min_slice_size=input_layer_min_slice_size
                )
            )

        super(MultiTaskEstimator, self).__init__(
            model_fn=multi_task_model_fn,
            model_dir=model_dir,
            config=config,
            params={
                "multi_tasks": self._multi_tasks,
                "head": self._multi_head,
                "feature_columns": self._feature_columns,
                "optimizer": optimizer,
                "learning_rate": learning_rate,
                "activation_fn": activation_fn,
                "dropout": dropout,
                "batch_norm": batch_norm,
                "beta": beta,
                "gradient_clip_norm": gradient_clip_norm,
                "embedding_lr_multipliers": embedding_lr_multipliers,
                "input_layer_partitioner": input_layer_partitioner,
                "learning_rate_decay_fn": learning_rate_decay_fn,
                "weights_initializer": weights_initializer
            },
            feature_engineering_fn=feature_engineering_fn
        )

    def predict(
            self,
            x=None,
            input_fn=None,
            batch_size=None,
            outputs=None,
            as_iterable=True
    ):
        """

        :param x:
        :param input_fn:
        :param batch_size:
        :param outputs: list of `tuple`, name of the output to predict. prediction_key:
                CLASSES = "classes"
                PROBABILITIES = "probabilities"
                LOGITS = "logits"
                LOGISTIC = "logistic
                SCORES = "scores"
                TOP_K = "top_k"
                GENERIC = "output"
                outputs here is a list of tuple, [(head_name, prediction_key)], note: prediction_key must be coordinated with task type
        :param as_iterable:
        :return:
        """
        if outputs is None:
            outputs = []
            for task_name, task in self._multi_tasks.get_tasks().items():
                if task.task_type == 'classification':
                    outputs.append((task_name+'_head', prediction_key.PredictionKey.PROBABILITIES))
                    outputs.append((task_name + '_head', prediction_key.PredictionKey.CLASSES))
                elif task.task_type == 'regression':
                    outputs.append((task_name+'_head', prediction_key.PredictionKey.SCORES))
        return super(MultiTaskEstimator, self).predict(
            x=x,
            input_fn=input_fn,
            batch_size=batch_size,
            outputs=outputs,
            as_iterable=as_iterable
        )

    def evaluate(self,
               x=None,
               y=None,
               input_fn=None,
               feed_fn=None,
               batch_size=None,
               steps=None,
               metrics=None,
               name=None,
               checkpoint_path=None,
               hooks=None):
        """

        :param x:
        :param y:
        :param input_fn:
        :param feed_fn:
        :param batch_size:
        :param steps:
        :param metrics: a dict from `str` key to MetricSpec. A typical format for multi-head，{(metric_op_name, head_name):metric_op}
        :param name:
        :param checkpoint_path:
        :param hooks:
        :param log_progress:
        :return:
        """
        return super(MultiTaskEstimator, self).evaluate(
            x=x,
            y=y,
            input_fn=input_fn,
            feed_fn=feed_fn,
            batch_size=batch_size,
            steps=steps,
            metrics=metrics,
            name=name,
            checkpoint_path=checkpoint_path,
            hooks=hooks
        )

    def export(self,
             export_dir,
             input_fn=None,
             input_feature_key=None,
             use_deprecated_input_fn=True,
             signature_fn=None,
             prediction_key=None,
             default_batch_size=1,
             exports_to_keep=None,
             checkpoint_path=None):
        def default_input_fn(unused_estimator, examples):
            return layers.parse_feature_columns_from_examples(examples, self._feature_columns)

        return super(MultiTaskEstimator, self).export(
            export_dir=export_dir,
            input_fn=input_fn or default_input_fn,
            input_feature_key=input_feature_key,
            use_deprecated_input_fn=use_deprecated_input_fn,
            signature_fn=signature_fn,
            prediction_key=prediction_key,
            default_batch_size=default_batch_size,
            exports_to_keep=exports_to_keep
        )
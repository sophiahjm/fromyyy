#!/usr/bin/env python
# -*- coding: utf-8 -*-
# @Time    : 18/5/15 PM4:51
# @Author  : shaoguang.csg
# @File    : conf.py

import tensorflow as tf

IS_LOCAL = True

tf.app.flags.DEFINE_string("tables", ",,", "tables info")  # -Dtables
tf.app.flags.DEFINE_string("checkpointDir", "", "checkpointDir info")  # -D
tf.app.flags.DEFINE_string("outputs", "", "outputs info")

FLAGS = tf.app.flags.FLAGS


def get_data_path(is_local):
    return '/Users/cheng/Data/nlp/item_title_summarize/item_title_caption' if is_local else FLAGS.tables.split(',')[0]


def get_base_model_dir(is_local):
    return '/Users/cheng/Data/nlp/item_title_summarize' if is_local else FLAGS.checkpointDir

DATA_PATH = get_data_path(IS_LOCAL)
BASE_MODEL_DIR = get_base_model_dir(IS_LOCAL)

BATCH_SIZE = 256
NUM_EPOCH = 10
VOCAB_SIZE = 3004
EMBEDDING_SIZE = 100
RNN_SIZE = 100
NUM_DECODER_LAYER = 2
ATTENTION_DEPTH = RNN_SIZE

LR = 0.01
LR_DECAY_STEPS = 4000
MAX_ITERATION = 12000
WEIGHT_DECAY_RATE = 0.0001


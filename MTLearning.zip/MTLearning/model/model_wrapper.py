#!/usr/bin/env python
# -*- coding: utf-8 -*-
# @Time    : 18/1/23 PM8:21
# @Author  : shaoguang.csg
# @File    : model_wrapper.py

import pandas as pd
from functools import partial
import tensorflow as tf
from tensorflow.contrib.learn import monitors

from utils.logger import logger
from model.model_core import ModelCore
from parse_conf import ModelConf, DataConf
from utils.system_op import wcl
from model.make_batch_data import Dataset, make_tf_batch_columns


class MTLWrapper(object):

    def __init__(self, data_conf:DataConf, model_conf:ModelConf):
        self._data_conf = data_conf
        self._model_conf = model_conf

        self._train_data = None
        self._validation_data = None
        self._test_data = None

        self._feature_columns = self.get_feature_columns() # TODO check whether this columns is None

        self._model = ModelCore(data_conf=data_conf, model_conf=ModelConf)

    def train(self):
        num_examples = wcl(self._data_conf.train_file)-1
        logger.info("{num_examples} examples in {filename}".format(num_examples=num_examples, filename=self._data_conf.train_file))

        logger.info("start to training the model ...")

        if self._model_conf.data_mode == 1 or self._train_data is None:
            self._train_data = self._load_data(
                self._data_conf.train_file,
                self._model_conf.data_mode,
                chunksize=10000000,
                separator=self._data_conf.column_separator
            )

        self.add_validation_monitor()

    def get_weight(self):
        return self._model.get_weight()

    def add_validation_monitor(self):
        if self._data_conf.evaluate_file is not None:
            valid_monitor = partial(
                monitors.ValidationMonitor,
                input_fn=lambda: self.build_validation_input_fn(),
                eval_steps=1,
                every_n_steps=self._model_conf.evaluate_interval,
                metrics=self._model._metrics
            )

            if self._model_conf.early_stopping_interval > 0:
                valid_monitor = valid_monitor(
                    early_stopping_rounds=self._model_conf.early_stopping_interval,
                    early_stopping_metric="loss",
                    early_stopping_metric_minimize=True
                )

            self._model.add_monitor(valid_monitor)

    def build_validation_input_fn(self):
        pass

    def get_feature_columns(self):
        feature_columns = []
        for columns in [self._data_conf.continuous_columns, self._data_conf.multi_category_columns]:
            feature_columns += columns if columns is not None else []
        if self._data_conf.multi_hot_columns is not None:
            feature_columns += list(self._data_conf.multi_hot_columns.keys())
        return feature_columns

    @staticmethod
    def _load_data(filename, big_data_mode, columns=None, chunksize=10000000, separator=','):
        logger.info("loading data from disk ...")
        if filename is None:
            logger.error('Can not load the data, filename is None')
            raise FileExistsError

        if big_data_mode:
            data = pd.read_csv(filename, sep=separator, usecols=columns, header='infer', engine='c', chunksize=chunksize)
        else:
            data = pd.read_csv(filename, sep=separator, header='infer', engine='c')
        return data
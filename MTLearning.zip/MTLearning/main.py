#!/usr/bin/env python
# -*- coding: utf-8 -*-
# @Time    : 17/12/12 PM2:33
# @Author  : shaoguang.csg
# @File    : main.py

from parse_conf import DataConf, ModelConf
from model.multi_task_estimator import MultiTaskEstimator
from task.multi_task import Multitask
from task.task import Task

data_conf = DataConf()
model_conf = ModelConf()

#for k, v in model_conf.multi_tasks.get_tasks().items():
#    print(type(v))

estimator = MultiTaskEstimator(model_conf.multi_tasks)
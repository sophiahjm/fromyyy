#!/usr/bin/env python
# -*- coding: utf-8 -*-
# @Time    : 17/12/7 PM2:07
# @Author  : shaoguang.csg
# @File    : system_op.py

import os
from utils.logger import logger


def wcl(filename):
    """
    wc -l filename
    :param filename:
    :return:
    """
    if not os.path.exists(filename):
        logger.error('{} does not exists'.format(filename))
        raise FileNotFoundError
    cmd = 'wc -l ' + filename
    line = os.popen(cmd).readline().strip()
    return int(line.split()[0])


def object_to_str(obj):
    """
    convert object to str
    :param obj:
    :return:
    """
    if type(obj) in (tuple, list):
        for idx in range(len(obj)):
            obj[idx] = object_to_str(obj[idx])
    elif type(obj) == dict:
        for key in obj:
            obj[key] = object_to_str(obj[key])
    elif type(obj) not in (int, str, float, type(None)):
        obj = obj.__dict__
        for elem in obj:
            obj[elem] = object_to_str(obj[elem])
    return obj


def is_contain_array(src, dest):
    """
    check whether each element of dest in src
    :param src:
    :param dest:
    :return:
    """
    assert type(src) in (tuple, list, dict), "src must be a collection"
    if type(dest) in (tuple, list, dict):
        for elem in dest:
            if not elem in src:
                return False
        return True
    else:
        return dest in src


if __name__ == '__main__':
    src = [1,2,3]
    dest = [3]
    print(is_contain_array(src, dest))

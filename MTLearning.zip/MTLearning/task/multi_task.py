#!/usr/bin/env python
# -*- coding: utf-8 -*-
# @Time    : 17/12/7 PM3:18
# @Author  : shaoguang.csg
# @File    : multi_task.py

from task.task import Task
from utils.logger import logger
from utils.system_op import object_to_str


class Multitask(object):

    def __init__(self):
        self._tasks = {}

    def add_task(self, task: Task):
        self._tasks[task.task_name] = task

    def get_tasks(self):
        return self._tasks

    def num_task(self):
        return len(self._tasks)

    @property
    def common_hidden_units(self):
        return self._common_hidden_units

    @common_hidden_units.setter
    def common_hidden_units(self, value):
        if not isinstance(value, list):
            logger.error("common_hidden_units of multi-task must be <list>")
            raise TypeError
        self._common_hidden_units = value

    @property
    def common_features(self):
        return self._common_features

    @common_features.setter
    def common_features(self, value):
        if not isinstance(value, list):
            logger.error("common_features of multi-task must be <list>")
            raise TypeError
        self._common_features = value

    @property
    def common_feature_columns(self):
        return self._common_feature_columns

    @common_feature_columns.setter
    def common_feature_columns(self, value):
        if not isinstance(value, list):
            logger.error("common_feature_columns of multi-task must be <list>")
            raise TypeError
        self._common_feature_columns = value

    def __str__(self):
        return str(object_to_str(self))
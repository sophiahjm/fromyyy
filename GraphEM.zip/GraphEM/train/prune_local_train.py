#!/usr/bin/env python
# -*- coding: utf-8 -*-
# @Time    : 18/7/10 PM8:14
# @Author  : shaoguang.csg
# @File    : local_train.py

import tensorflow as tf
import numpy as np
import os

from utils.util import clock, count_param
from utils.logger import logger
from models.prune import Prune
from common.batch_reader import TableBatchReader
from common.table_ops import WriteEmbedding2Table
from conf.prune_conf import PruneConf
from serialization.serialization import node_attr_id_mapping, node_attr_2_idx
from common.graph_metric import link_prediction


def gen_train_batch(dataset, vocab_to_idx, num_id_cols, num_text_col,
                    node_outin_degree, node_attr_ids, node_text_ids, pmi_const, max_text_length):
    lines = dataset.next_batch()  # start_node, end_node
    if lines is None:
        return [None]*11

    if PruneConf.IS_LOCAL:
        lines = lines.astype(np.str)

    start_nodes_batch = [vocab_to_idx[node] for node in lines[:,0]]
    end_nodes_batch = [vocab_to_idx[node] for node in lines[:,1]]

    out_degree_batch = [node_outin_degree[node][0] for node in lines[:,0]]  # out degree of start node
    in_degree_batch = [node_outin_degree[node][1] for node in lines[:,1]]  # in degree of end node
    pmi_batch = [max(0, np.log(pmi_const/out_degree_batch[idx]/in_degree_batch[idx])) for idx in range(len(lines))]
#    pmi_batch = np.array(pmi_batch).reshape((-1,1))

    start_node_id_batch = {}
    end_node_id_bacth = {}
    if num_id_cols > 0:
        for attr_name, attr_value in node_attr_ids.items():
            start_node_id_batch[attr_name] = [attr_value[node] for node in lines[:,0]]
            end_node_id_bacth[attr_name] = [attr_value[node] for node in lines[:,1]]

    def _pad_line(line, max_text_length):
        return line[:max_text_length] if len(line) >= max_text_length else line+[0]*(max_text_length-len(line))

    start_text_batch = []
    start_text_mask_batch = None
    end_text_batch = []
    end_text_mask_batch = None
    if num_text_col > 0:
        start_text_batch = [node_text_ids[node] for node in lines[:,0]]
        end_text_batch = [node_text_ids[node] for node in lines[:,1]]
        start_text_batch = np.array([_pad_line(line, max_text_length) for line in start_text_batch])
        end_text_batch = np.array([_pad_line(line, max_text_length) for line in end_text_batch])
        start_text_mask_batch = np.array(start_text_batch > 0, dtype=np.int32)
        end_text_mask_batch = np.array(end_text_batch > 0, dtype=np.int32)
    return start_nodes_batch, end_nodes_batch, out_degree_batch, in_degree_batch, \
           pmi_batch, start_node_id_batch, end_node_id_bacth, start_text_batch, \
           end_text_batch, start_text_mask_batch, end_text_mask_batch


@clock
def train(conf):
    idx_to_vocab, vocab_to_idx = node_attr_id_mapping(conf)
    node_outin_degree, node_attr_ids, node_text_ids = node_attr_2_idx(conf, vocab_to_idx)

    attr_size = {k:len(v) for k,v in vocab_to_idx.items()}
    logger.info("Attribute size: {}".format(attr_size))

    num_id_cols = len(conf.attribute_id_cols)
    num_text_col = 1 if conf.attribute_text_col is not None else 0
    max_text_length = int(conf.attribute_text_col.get('max_length', -1)) if num_text_col > 0 else -1
    num_epoch = int(conf.max_iteration*conf.batch_size/conf.num_edge)+1

    selected_cols = ','.join([conf.start_node_col_name, conf.end_node_col_name])

    with tf.Graph().as_default() as graph:
        dataset = TableBatchReader(
            [conf.edge_table],
            selected_cols=selected_cols,
            batch_size=conf.batch_size,
            num_epoch=num_epoch,
            is_shuffle=True
        )
        
        prune_model = Prune(conf, attr_size)
        prune_model.build_graph()
        prune_model.build_optimizer()
        [train_op, loss_op, proximity_loss_op,ranking_loss_op] = prune_model.train_op, prune_model.loss, prune_model.proximity_loss, prune_model.ranking_loss

        summary_op = tf.summary.merge_all()
        summary_writer = tf.summary.FileWriter(os.path.join(conf.checkpoint_dir, 'summary_log'), graph=graph)
        saver = tf.train.Saver()

        config = tf.ConfigProto(
            gpu_options=tf.GPUOptions(allow_growth=True),
            allow_soft_placement=True,
        )
        session = tf.Session(config=config)
        session.run(tf.local_variables_initializer())
        session.run(tf.global_variables_initializer())

        count_param()

        vocab_to_idx = vocab_to_idx['node']
        pmi_const = conf.num_edge*1.0/conf.alpha
        for step in range(conf.max_iteration):
            start_nodes_batch, end_nodes_batch, out_degree_batch, in_degree_batch, \
            pmi_batch, start_node_id_batch, end_node_id_bacth, start_text_batch, \
            end_text_batch, start_text_mask_batch, end_text_mask_batch = gen_train_batch(
                dataset, vocab_to_idx, num_id_cols, num_text_col,
                node_outin_degree, node_attr_ids, node_text_ids, pmi_const, max_text_length)

            if start_nodes_batch is None:
                break

            feed_dict = {
                prune_model.start_nodes: start_nodes_batch,
                prune_model.end_nodes: end_nodes_batch,
                prune_model.out_degrees: out_degree_batch,
                prune_model.in_degrees: in_degree_batch,
                prune_model.PMI: pmi_batch,
            }

            if num_id_cols > 0:
                for attr_name, value in start_node_id_batch.item():
                    feed_dict[prune_model.start_id_attr_placeholder[attr_name]] = value
                for attr_name, value in end_node_id_bacth.item():
                    feed_dict[prune_model.end_id_attr_placeholder[attr_name]] = value

            if num_text_col > 0:
                feed_dict[prune_model.start_text_attr_placeholder] = start_text_batch
                feed_dict[prune_model.start_text_mask_placeholder] = start_text_mask_batch
                feed_dict[prune_model.end_text_attr_placeholder] = end_text_batch
                feed_dict[prune_model.end_text_mask_placeholder] = end_text_mask_batch

            [_, loss, proximity_loss, ranking_loss] = session.run([train_op, loss_op, proximity_loss_op, ranking_loss_op], feed_dict=feed_dict)
            if step % 2 == 0:
                logger.info("step {}, total_loss {}, proximity_loss {}, ranking_loss {}".format(step, loss, proximity_loss, ranking_loss))

            if step % 100 == 0:
                summary_str = session.run(summary_op, feed_dict=feed_dict)
                summary_writer.add_summary(summary_str, step)

            if conf.eval_table is not None and (step % 10000 == 0 or step == conf.max_iteration-1):
                # do validation here
                logger.info("do link prediction ...")
                link_prediction(prune_model, session, conf.eval_table, selected_cols+',label', vocab_to_idx)

        # write embedding to table
        write_embedding_to_table(session, conf.embedding_result_table, prune_model, idx_to_vocab['node'])


@clock
def write_embedding_to_table(session, table_name, prune_model, idx_to_vocab):
    cnt = 0
    batch_ids, batch_nodes = [], []
    writer = WriteEmbedding2Table(table_name)
    for idx, node_id in idx_to_vocab.items():
        if len(batch_ids) < conf.batch_size-1:
            batch_ids.append(str(idx))
            batch_nodes.append(node_id)
            continue
        batch_ids.append(idx)
        batch_nodes.append(node_id)
        embeddings = prune_model.get_embedding(session, batch_ids)
        embeddings = [','.join(_) for _ in embeddings.astype(np.str)]
        writer.write(batch_nodes, embeddings)  # node_id, embedding
        cnt += len(embeddings)
        if cnt % 50000 == 0:
            logger.info("write {} nodes to table".format(cnt))
        batch_ids, batch_nodes = [], []

    if len(batch_ids) > 0:
        embeddings = prune_model.get_embedding(session, batch_ids)
        embeddings = [','.join(_) for _ in embeddings.astype(np.str)]
        writer.write(batch_nodes, embeddings)
        cnt += len(embeddings)
    writer.stop()
    logger.info("Totally write {} nodes to table".format(cnt))


if __name__ == '__main__':
    conf = PruneConf()

    train(conf)
#!/usr/bin/env python
# -*- coding: utf-8 -*-
# @Time    : 18/10/3 AM9:57
# @Author  : shaoguang.csg
# @File    : graph_metric_learning.py

from models.basic_model import BasicModel
from utils.distance import cal_distance

import tensorflow as tf
import tensorflow.contrib.layers as layers
from tensorflow.python.ops import embedding_ops


class GraphMetricLearning(BasicModel):
    def __init__(self, conf, attr_size):
        super(GraphMetricLearning, self).__init__(conf)

        self.conf = conf
        self.attr_size = attr_size

    def build_graph(self):
        self.anchor_nodes = tf.placeholder(dtype=tf.int32, shape=[self.conf.batch_size], name='anchor_nodes')
        self.pos_nodes = tf.placeholder(dtype=tf.int32, shape=[self.conf.batch_size], name='pos_nodes')
        self.neg_nodes = tf.placeholder(dtype=tf.int32, shape=[self.conf.batch_size, self.conf.alpha], name='neg_nodes')
        self.anchor_neighbor_nodes = tf.placeholder(dtype=tf.int32, shape=[self.conf.batch_size, self.conf.max_neighbor], name='anchor_neighbor_nodes')
        self.anchor_neighbor_mask = tf.placeholder(dtype=tf.int32, shape=[self.conf.batch_size, self.conf.max_neighbor,1], name='anchor_neighbor_mask')
        self.real_neighbor_num = tf.placeholder(dtype=tf.int32, shape=[self.conf.batch_size,1], name='real_neighbor_num')

        self.nodes_embedding = tf.get_variable(
            "nodes_embedding",
            shape=(self.attr_size['node'], self.conf.embed_size),
            dtype=tf.float32,
            initializer=layers.xavier_initializer(),
            trainable=True,
            partitioner=tf.min_max_variable_partitioner(
                max_partitions=self.conf.num_ps if self.conf.num_ps is not None else 1,
                min_slice_size=256 << 10
            )
        )

        self.anchor_nodes_embed = self.get_embedding(self.nodes_embedding, self.anchor_nodes)  # nxk
        self.anchor_neighbor_embed = self.get_embedding(self.nodes_embedding, self.anchor_neighbor_nodes)  # n x max_neighbor x k
        self.anchor_neighbor_mask = tf.cast(self.anchor_neighbor_mask, dtype=tf.float32)  # n x max_neighbor x 1
        self.anchor_neighbor_embed = tf.multiply(self.anchor_neighbor_embed, self.anchor_neighbor_mask)  # n x max_neighbor x k

        if self.conf.model_type == 'first_order':
            self.pos_nodes_embed = self.get_embedding(self.nodes_embedding, self.pos_nodes)  # nxk
            self.neg_nodes_embed = self.get_embedding(self.nodes_embedding, self.neg_nodes)  # n x alpha x k
        else:
            self.context_embedding = tf.get_variable(
                "context_embedding",
                shape=(self.attr_size['node'], self.conf.embed_size),
                dtype=tf.float32,
                initializer=layers.xavier_initializer(),
                trainable=True,
                partitioner=tf.min_max_variable_partitioner(
                    max_partitions=self.conf.num_ps if self.conf.num_ps is not None else 1,
                    min_slice_size=256 << 10
                )
            )
            self.pos_nodes_embed = self.get_embedding(self.context_embedding, self.pos_nodes)
            self.neg_nodes_embed = self.get_embedding(self.context_embedding, self.neg_nodes)

#        self.neg_nodes_embed = tf.reshape(self.neg_nodes_embed, shape=(-1, self.conf.embed_size))

#        self.weight = tf.get_variable("weight", shape=(self.conf.embed_size, self.conf.embed_size), dtype=tf.float32,
#                                      initializer=layers.xavier_initializer())
#        self.bias = tf.get_variable("bias", shape=self.conf.embed_size, dtype=tf.float32,
#                                    initializer=tf.constant_initializer(0.0))

        # 加入一个fc层
#        self.anchor_nodes_embed = tf.nn.selu(tf.matmul(self.anchor_nodes_embed, self.weight) + self.bias)
#        self.pos_nodes_embed = tf.nn.selu(tf.matmul(self.pos_nodes_embed, self.weight) + self.bias)
#        self.neg_nodes_embed = tf.nn.selu(tf.matmul(self.neg_nodes_embed, self.weight) + self.bias)
#        self.neg_nodes_embed = tf.reshape(self.neg_nodes_embed,
#                                          shape=(self.conf.batch_size, self.conf.alpha, self.conf.embed_size))

        self.anchor_neighbor_embed = tf.reduce_sum(self.anchor_neighbor_embed, axis=1)
        self.construct_embed = tf.div(self.anchor_neighbor_embed, tf.cast(self.real_neighbor_num, dtype=tf.float32))  # n x k
        self.construct_loss = cal_distance(self.construct_embed, self.anchor_nodes_embed, self.conf.distance_type, axis=1)
        self.construct_loss = tf.reduce_mean(self.construct_loss)

        self.anchor_pos_distance = cal_distance(self.anchor_nodes_embed, self.pos_nodes_embed, self.conf.distance_type,
                                                axis=1)  # nx1
        self.anchor_neg_distance = cal_distance(tf.expand_dims(self.anchor_nodes_embed, axis=1), self.neg_nodes_embed,
                                                self.conf.distance_type, axis=2)  # nxk
        self.anchor_neg_distance = tf.reduce_mean(self.anchor_neg_distance, axis=1)  # nx1
        self.margin_loss = tf.reduce_mean(
            tf.maximum(self.anchor_pos_distance - self.anchor_neg_distance + self.conf.margin, 0))

        self.loss = self.margin_loss + self.construct_loss

        tf.summary.scalar('loss', self.loss)
        tf.summary.scalar('margin_loss', self.margin_loss)
        tf.summary.scalar('construct_loss', self.construct_loss)


        # 一个正样本重复多次与每一个负样本组成pair
        #        self.loss = tf.reduce_mean(tf.maximum(tf.expand_dims(self.anchor_pos_distance, axis=1) - self.anchor_neg_distance + self.conf.margin, 0))
        #        tf.summary.scalar('triplet loss', self.loss)

        # 一种新的loss: loss(i, j) = max(alpha + Yij*(D(i,j)-beta))

        # 构建获取最终输出的节点表达图
#        self.nodes = tf.placeholder(dtype=tf.int32, shape=[self.conf.batch_size], name="output_nodes")
#        nodes_embed = self.get_embedding(self.nodes_embedding, self.nodes)
#        self.nodes_output_embed = tf.nn.selu(tf.matmul(nodes_embed, self.weight) + self.bias)

    def get_embedding(self, nodes_embedding, node_ids):
        return embedding_ops.embedding_lookup(nodes_embedding, node_ids)

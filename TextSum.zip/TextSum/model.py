#!/usr/bin/env python
# -*- coding: utf-8 -*-
# @Time    : 18/5/15 PM5:06
# @Author  : shaoguang.csg
# @File    : model.py

from functools import partial

import tensorflow as tf
import tensorflow.contrib.layers as layers
import tensorflow.contrib.rnn as rnn
import tensorflow.contrib.seq2seq as seq2seq


#from .conf import (
#    BATCH_SIZE,
#    VOCAB_SIZE,
#    EMBEDDING_SIZE,
#    RNN_SIZE,
#    ATTENTION_DEPTH,
#    LR,
#    WEIGHT_DECAY_RATE,
#    LR_DECAY_STEPS
#)


from conf import (
    BATCH_SIZE,
    VOCAB_SIZE,
    EMBEDDING_SIZE,
    RNN_SIZE,
    ATTENTION_DEPTH,
    LR,
    WEIGHT_DECAY_RATE,
    LR_DECAY_STEPS
)


class Seq2SeqModel(object):
    def __init__(self, ):
        pass

    def _build_inputs(self):
        # training placeholder
        self.inputs = tf.placeholder(dtype=tf.int32, shape=[None, None], name='inputs')
        self.targets = tf.placeholder(dtype=tf.int32, shape=[None, None], name='targets')

        self.target_sequence_length = tf.placeholder(tf.int32, (None,), name='target_sequence_length')
        self.max_target_sequence_length = tf.placeholder(tf.int32, (), name='max_target_sequence_length')
        self.source_sequence_length = tf.placeholder(tf.int32, (None,), name='source_sequence_length')

        self.keep_prob = tf.placeholder(tf.float32, (), name='keep_prob')

        # inference placeholder
        self.num_sequences_to_decode = tf.placeholder(dtype=tf.int32, shape=(), name='num_seq_to_decode')

    def _build_encoder_layer(self):
        encoder_embed_input = layers.embed_sequence(
            self.inputs,
            vocab_size=VOCAB_SIZE,
            embed_dim=EMBEDDING_SIZE,
            regularizer=tf.nn.l2_loss,
            unique=True,
            trainable=True,
            scope='vocab_embedding'
        )

        def _get_bilstm_cell():
            fw_cell = rnn.DropoutWrapper(
                rnn.LSTMCell(
                    num_units=RNN_SIZE,
                    initializer=tf.glorot_uniform_initializer()
                ),
                output_keep_prob=self.keep_prob
            )
            bw_cell = rnn.DropoutWrapper(
                rnn.LSTMCell(
                    num_units=RNN_SIZE,
                    initializer=tf.glorot_uniform_initializer()
                ),
                output_keep_prob=self.keep_prob
            )

            return fw_cell, bw_cell

        fw_cell, bw_cell = _get_bilstm_cell()
#        encoder_output, encoder_state = tf.nn.dynamic_rnn(
#            cell=fw_cells,
#            inputs=encoder_embed_input,
#            sequence_length=self.source_sequence_length,
#            dtype=tf.float32
#        )

        for var in tf.trainable_variables():
            if var.op.name.find(r'kernel') > 0:
                print(var)

        encoder_output, encoder_state = tf.nn.bidirectional_dynamic_rnn(
            cell_bw=fw_cell,
            cell_fw=bw_cell,
            inputs=encoder_embed_input,
            sequence_length=self.source_sequence_length,
            dtype=tf.float32
        )
        return tf.concat(encoder_output, 2), encoder_state

    @staticmethod
    def _process_decoder_input(inputs, vocab_to_int, batch_size):
        ending = tf.strided_slice(inputs, begin=[0,0], end=[batch_size,-1], strides=[1,1])
        decoder_inputs = tf.concat([tf.fill([batch_size,1], vocab_to_int['<GO>']), ending], axis=1)
        return decoder_inputs

    def _build_decoder_layer(self, decoder_inputs, encoder_outputs, encoder_states, vocab_to_int, use_attention=False):
        decoder_embed_input = layers.embed_sequence(
            decoder_inputs,
            vocab_size=VOCAB_SIZE,
            embed_dim=EMBEDDING_SIZE,
            regularizer=tf.nn.l2_loss,
            unique=True,
            reuse=True,
            trainable=True,
            scope='vocab_embedding'
        )

        print('decoder_embed_input shape: ', decoder_embed_input.shape)

        def _get_decoder_cell():
            cell = rnn.LSTMCell(
                num_units=RNN_SIZE,
                initializer=tf.glorot_uniform_initializer(),
                state_is_tuple=True
            )
#            cell = rnn.MultiRNNCell([cell], state_is_tuple=True)

            if use_attention:
                attention_mechanism = seq2seq.LuongAttention(
                    num_units=ATTENTION_DEPTH,
                    memory=encoder_outputs,  # [batch_size, steps, rnn_size]
                    memory_sequence_length=self.source_sequence_length,
                )
                cell = seq2seq.AttentionWrapper(
                    cell=cell,
                    attention_mechanism=attention_mechanism,
                    alignment_history=True,
                    output_attention=True
                )
            return cell

        cell = _get_decoder_cell()

        output_layer = tf.layers.Dense(
            units=VOCAB_SIZE,
            kernel_initializer=tf.truncated_normal_initializer(mean=0.0,stddev=0.01)
        )

        with tf.variable_scope('decoder'):
            training_helper = seq2seq.TrainingHelper(
                inputs=decoder_embed_input,
                sequence_length=self.target_sequence_length,
                time_major=False
            )

            training_decoder_init_state = cell.zero_state(BATCH_SIZE, tf.float32)\
                .clone(cell_state=encoder_states) if use_attention else encoder_states # AttentionWrapperState

            training_decoder = seq2seq.BasicDecoder(
                cell=cell,
                helper=training_helper,
                initial_state=training_decoder_init_state,
                output_layer=output_layer
            )

            training_decoder_outputs, training_decoder_state, training_decoder_sequence_lengths = seq2seq.dynamic_decode(
                decoder=training_decoder,
                output_time_major=False,
                impute_finished=True,
                maximum_iterations=self.max_target_sequence_length
            )

#            training_attention_matrix = training_decoder_state  # visualize attention matrix

        with tf.variable_scope(name_or_scope='vocab_embedding', reuse=True):
            decoder_embedding = tf.get_variable(name='embeddings')

        with tf.variable_scope('decoder', reuse=True):
            start_tokens = tf.tile(tf.constant([vocab_to_int['<GO>']], dtype=tf.int32), [self.num_sequences_to_decode])
            inference_helper = seq2seq.GreedyEmbeddingHelper(
                embedding=decoder_embedding,
                start_tokens=start_tokens,
                end_token=vocab_to_int['<EOS>']
            )

            inference_decoder_init_state = cell.zero_state(self.num_sequences_to_decode, tf.float32)\
                .clone(cell_state=encoder_states) if use_attention else encoder_states # AttentionWrapperState

            inference_decoder = seq2seq.BasicDecoder(
                cell=cell,
                helper=inference_helper,
                initial_state=inference_decoder_init_state,
                output_layer=output_layer
            )
            inference_decoder_outputs, inference_final_state, final_sequence_lengths = seq2seq.dynamic_decode(
                decoder=inference_decoder,
                output_time_major=False,
                impute_finished=True,
                maximum_iterations=self.max_target_sequence_length
            )

        return training_decoder_outputs, inference_decoder_outputs

    def build_graph(self, vocab_to_int):
        global_step = tf.Variable(initial_value=0, name='global_step', trainable=False)

        self._build_inputs()  # build kinds of input placeholder

        encoder_outputs, encoder_states = self._build_encoder_layer()
        decoder_inputs = self._process_decoder_input(
            self.targets,
            vocab_to_int=vocab_to_int,
            batch_size=BATCH_SIZE
        )

        print('decoder_inputs shape: ', decoder_inputs.shape)

        training_decoder_outputs, inference_decoder_outputs = self._build_decoder_layer(
            decoder_inputs=decoder_inputs,
            encoder_outputs=encoder_outputs,
            encoder_states=encoder_states[0],
            vocab_to_int=vocab_to_int,
            use_attention=True
        )

        self.training_logits = tf.identity(training_decoder_outputs.rnn_output, name='training_logits')
        self.inference_logits = tf.identity(inference_decoder_outputs.sample_id, name='inference_logits')

        masks = tf.sequence_mask(
            self.target_sequence_length,
            self.max_target_sequence_length,
            dtype=tf.float32,
            name='sequence_masks'
        )

        # cal l2loss
        l2_costs = []
        [l2_costs.append(tf.nn.l2_loss(var)) for var in tf.trainable_variables() if var.op.name.find(r'kernel') > 0]
        self.l2_loss = WEIGHT_DECAY_RATE*tf.add_n(l2_costs)

        self.sequence_loss = seq2seq.sequence_loss(
            logits=self.training_logits,
            targets=self.targets,
            weights=masks
        )

        self.loss = self.sequence_loss + self.l2_loss

        self.learning_rate = tf.train.exponential_decay(
            learning_rate=LR,
            global_step=global_step,
            decay_steps=LR_DECAY_STEPS,
            decay_rate=0.1,
            staircase=True
        )
        self.learning_rate = tf.maximum(self.learning_rate, 1e-6)

        optimizer = tf.train.AdamOptimizer(learning_rate=self.learning_rate)
        gradients = optimizer.compute_gradients(loss=self.loss)  # do gradients clipping
        clipped_gradients = [(tf.clip_by_value(grad, -5.0, 5.0), var) for grad, var in gradients if grad is not None]
        train_op = optimizer.apply_gradients(clipped_gradients, global_step=global_step)

        tf.summary.scalar(name='sequence_loss', tensor=self.sequence_loss)
        tf.summary.scalar(name='l2_loss', tensor=self.l2_loss)
        tf.summary.scalar(name='total_loss', tensor=self.loss)
        tf.summary.scalar('learning_rate', self.learning_rate)

        return train_op, self.inference_logits



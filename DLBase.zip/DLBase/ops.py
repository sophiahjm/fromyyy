#!/usr/bin/env python
# -*- coding: utf-8 -*-
# @Time    : 18/5/15 PM3:44
# @Author  : shaoguang.csg
# @File    : ops.py

import tensorflow as tf


def softmax(logits, dims=-1):
    """
    Compute softmax over specified dimensions.
    """
    exp = tf.exp(logits - tf.reduce_max(logits, dims, keep_dims=True))
    return exp / tf.reduce_sum(exp, dims, keep_dims=True)


def entropy(logits, dims=-1):
    """
    Compute entropy over specified dimensions.
    """
    probs = softmax(logits, dims)
    nplogp = probs * (tf.reduce_logsumexp(logits, dims, keep_dims=True) - logits)
    return tf.reduce_sum(nplogp, dims)


def leaky_relu(x, alpha=0.1):
    """
    Computes the leaky rectified linear activation.
    """
    return tf.maximum(x, alpha * x)

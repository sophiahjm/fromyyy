#!/usr/bin/env python
# -*- coding: utf-8 -*-
# @Time    : 17/12/7 PM2:49
# @Author  : shaoguang.csg
# @File    : task.py


from utils.logger import logger


class Task(object):

    def __init__(self, task_name):
        self._task_name = task_name
        self._loss_fn = None
        self._weight = None

    @property
    def hidden_units(self):
        return self._hidden_units

    @hidden_units.setter
    def hidden_units(self, value):
        if not isinstance(value, list):
            logger.error("hidden_units must be <list>")
            raise TypeError
        self._hidden_units = value

    @property
    def weight(self):
        """
        the weight of this task in all tasks, used to calculate total loss
        :return:
        """
        return self._weight

    @weight.setter
    def weight(self, value):
        self._weight = value

    @property
    def loss_fn(self):
        return self._loss_fn

    @loss_fn.setter
    def loss_fn(self, fn):
        if not callable(fn):
            logger.error("loss_fn must be callable")
            raise TypeError
        self._loss_fn = fn

    @property
    def num_class(self):
        return self._num_class

    @num_class.setter
    def num_class(self, value):
        if self._task_type == 'regression':
            logger.error("regression do not have num_class")
            raise TypeError
        assert value > 1
        self._num_class = value

    @property
    def task_type(self):
        return self._task_type

    @task_type.setter
    def task_type(self, value):
        if value not in ('classification', 'regression'):
            logger.error("task type must be in (classification, regression)")
            raise TypeError
        self._task_type = value

    @property
    def features(self):
        return self._features

    @features.setter
    def features(self, value):
        if not isinstance(value, list):
            logger.error("features of task must be <list>")
            raise TypeError
        self._features = value

    @property
    def feature_columns(self):
        return self._feature_columns

    @feature_columns.setter
    def feature_columns(self, value):
        if not isinstance(value, list):
            logger.error("feature columns of task must be <list>")
            raise TypeError
        self._feature_columns = value

    @property
    def target(self):
        return self._target

    @target.setter
    def target(self, value):
        if not isinstance(value, str):
            logger.error("target of task must be <str>")
            raise TypeError
        self._target = value

    @property
    def task_name(self):
        return self._task_name

    def __str__(self):
        return "{task_name} info: features->{features}, target->{target}, task_type->{task_type}, hidden_units->{hidden_units}"\
            .format(
            task_name=self.task_name,
            features=self.features,
            target=self.target,
            task_type=self.task_type,
            hidden_units=self.hidden_units
        )

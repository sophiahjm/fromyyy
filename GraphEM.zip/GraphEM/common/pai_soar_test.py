#!/usr/bin/env python
# -*- coding: utf-8 -*-
# @Time    : 18/7/10 PM8:33
# @Author  : shaoguang.csg
# @File    : pai_soar_test.py

# -*- coding: utf-8 -*-

import os
import sys
import argparse
import time

import tensorflow as tf
import tensorflow.contrib.pai_soar as pai

tf.app.flags.DEFINE_string('worker_hosts', '', 'must be list')
tf.app.flags.DEFINE_string('job_name', '', '')
tf.app.flags.DEFINE_integer('task_index', 0, '')
tf.app.flags.DEFINE_integer('max_steps', 100, 'max training step')
tf.app.flags.DEFINE_string('data_dir', './data/', 'input data')
tf.app.flags.DEFINE_float('learning_rate', 0.01, '')
FLAGS = tf.flags.FLAGS


def read_image(file_queue):
    reader = tf.TFRecordReader()
    key, value = reader.read(file_queue)
    _, serialized_example = reader.read(file_queue)
    features = tf.parse_single_example(
        serialized_example,
        features={
          'image_raw': tf.FixedLenFeature([], tf.string),
          'label': tf.FixedLenFeature([], tf.int64),
          })

    image = tf.decode_raw(features['image_raw'], tf.uint8)
    image.set_shape([784])
    image = tf.cast(image, tf.float32) * (1. / 255) - 0.5
    label = tf.cast(features['label'], tf.int32)
    return image, label

def read_image_batch(file_queue, batch_size):
    with tf.device('/job:worker/task:%d/cpu:0' % FLAGS.task_index):
      img, label = read_image(file_queue)
      capacity = 3 * batch_size
      image_batch, label_batch = tf.train.batch([img, label], batch_size=batch_size, capacity=capacity, num_threads=10)
      one_hot_labels = tf.to_float(tf.one_hot(label_batch, 10, 1, 0))
      return image_batch, one_hot_labels

def main(_):
  hosts = FLAGS.worker_hosts.split(",")
  cluster = tf.train.ClusterSpec({"worker": hosts})
  pai.enable_replicated_vars()

  # Create and start a server for the local task.
  server = tf.train.Server(cluster,
                           job_name=FLAGS.job_name,
                           task_index=FLAGS.task_index)

  with tf.device(tf.train.replica_device_setter(worker_device="/job:worker/task:%d" % FLAGS.task_index,
                                                cluster=cluster)):
    global_step = tf.Variable(0, name='global_step', trainable=False)
    train_file_path = os.path.join(FLAGS.data_dir, "train.tfrecords")
    test_file_path = os.path.join(FLAGS.data_dir, "test.tfrecords")

    train_image_filename_queue = tf.train.string_input_producer(
            [train_file_path])
    train_images, train_labels = read_image_batch(train_image_filename_queue, 100)

    test_image_filename_queue = tf.train.string_input_producer(
            [test_file_path])
    test_images, test_labels = read_image_batch(test_image_filename_queue, 100)

    # the Variables we need to train
    W = tf.Variable(tf.zeros([784, 10]))
    b = tf.Variable(tf.zeros([10]))

    x = tf.reshape(train_images, [-1, 784])
    y = tf.matmul(x, W) + b
    y_ = tf.to_float(train_labels)

    cross_entropy = tf.reduce_mean(
            tf.nn.softmax_cross_entropy_with_logits(labels=y_, logits=y))
    opt = tf.train.AdamOptimizer(FLAGS.learning_rate)
    opt = pai.ReplicatedVarsOptimizer(opt)
    train_step = opt.minimize(cross_entropy, global_step=global_step)

    x_test = tf.reshape(test_images, [-1, 784])
    y_pred = tf.matmul(x_test, W) + b
    y_test = tf.to_float(test_labels)

    correct_prediction = tf.equal(tf.argmax(y_pred, 1), tf.argmax(y_test, 1))
    accuracy = tf.reduce_mean(tf.cast(correct_prediction, tf.float32))
  is_chief = (FLAGS.task_index == 0)
  hooks=[tf.train.StopAtStepHook(last_step=FLAGS.max_steps)]
  sess_config = tf.ConfigProto(allow_soft_placement=True,
                             log_device_placement=False)
  with tf.train.MonitoredTrainingSession(master=server.target,
                                         is_chief=is_chief,
                                         config=sess_config,
                                         hooks=hooks) as sess:
    while not sess.should_stop():
      start_time = time.time()
      _, step, acc = sess.run([train_step, global_step, accuracy])
      duration = time.time() - start_time
      print('using time: %.3f, accuracy at step %s: %s' % (duration, step, acc))

if __name__ == '__main__':
    tf.app.run()
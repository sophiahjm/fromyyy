#!/usr/bin/env python
# -*- coding: utf-8 -*-
# @Time    : 18/5/15 PM5:05
# @Author  : shaoguang.csg
# @File    : train.py

import pickle
import os
import json

import numpy as np
import tensorflow as tf
from tensorflow.python.platform import gfile

#from TextSum.model import Seq2SeqModel
#from TextSum.extract_text_info import Dataset, extract_character_vocab, _is_chinese_char
#from TextSum.conf import (
#    IS_LOCAL,
#    DATA_PATH,
#    BASE_MODEL_DIR,
#    BATCH_SIZE,
#    NUM_EPOCH,
#    MAX_ITERATION
#)


from model import Seq2SeqModel
from extract_text_info import Dataset, extract_character_vocab, _is_chinese_char
from conf import (
    IS_LOCAL,
    DATA_PATH,
    BASE_MODEL_DIR,
    BATCH_SIZE,
    NUM_EPOCH,
    MAX_ITERATION,
    EMBEDDING_SIZE
)


def pad_sentence_batch(sentence_batch, pad_int):
    max_length = max([len(sentence) for sentence in sentence_batch])
    return [sentence + [pad_int] * (max_length - len(sentence)) for sentence in sentence_batch]


def get_batches(dataset, vocab_to_idx):
    lines = dataset.next_batch()
    if lines is None:
        return None, None, None, None

    if IS_LOCAL:
        source_batch = [[vocab_to_idx.get(char, vocab_to_idx['<UNK>']) for char in bytes.decode(line[2])
                        if _is_chinese_char(char)] for line in lines]
        target_batch = [[vocab_to_idx.get(char, vocab_to_idx['<UNK>']) for char in bytes.decode(line[1])
                        if _is_chinese_char(char)]+[vocab_to_idx['<EOS>']] for line in lines]
    else:
        source_batch = [[vocab_to_idx.get(char, vocab_to_idx['<UNK>']) for char in (line[2]).decode('utf-8')
                        if _is_chinese_char(char)] for line in lines]
        target_batch = [[vocab_to_idx.get(char, vocab_to_idx['<UNK>']) for char in (line[1]).decode('utf-8')
                        if _is_chinese_char(char)]+[vocab_to_idx['<EOS>']] for line in lines]

    source_batch_length = [len(source) for source in source_batch]
    target_batch_length = [len(target) for target in target_batch]
    max_source_batch_length = max(max(source_batch_length), 2)
    for idx, source_length in enumerate(source_batch_length):
        if source_length == 0:
            source_batch_length[idx] = max_source_batch_length

    pad_sources_batch = np.array(pad_sentence_batch(source_batch, vocab_to_idx['<PAD>']))
    pad_targets_batch = np.array(pad_sentence_batch(target_batch, vocab_to_idx['<PAD>']))

    return pad_sources_batch, pad_targets_batch, source_batch_length, target_batch_length


def save_model(session, inputs, outputs, saved_model_dir):
    builder = tf.saved_model.builder.SavedModelBuilder(export_dir=saved_model_dir)
    inputs = {k: tf.saved_model.utils.build_tensor_info(v) for k, v in inputs.items()}
    outputs = {k: tf.saved_model.utils.build_tensor_info(v) for k, v in outputs.items()}
    prediction_signature = tf.saved_model.signature_def_utils.build_signature_def(
        inputs,
        outputs,
        method_name='save_model_signature_def'
    )
    builder.add_meta_graph_and_variables(
        session,
        tags=[tf.saved_model.tag_constants.SERVING],
        signature_def_map={tf.saved_model.signature_constants.DEFAULT_SERVING_SIGNATURE_DEF_KEY:prediction_signature},
        clear_devices=True
    )
    builder.save()


def save_vocab_to_pickle(data, filename):
    fobj = open(filename, 'wb')
    pickle.dump(data, fobj)
    fobj.close()


def load_vocab_from_pickle(filename):
    fobj = open(filename, 'rb')
    data = pickle.load(fobj)
    fobj.close()
    return data


def save_vocab_to_oss(data, filename):
    data_str = json.dumps(data)
    gfile_writer = gfile.GFile(filename, mode='w')
    gfile_writer.write(data_str)
    gfile_writer.flush()
    gfile_writer.close()


def load_vocab_from_oss(filename):
    gfile_reader = gfile.GFile(filename, mode='r')
    data_str = gfile_reader.read(n=-1)
    gfile_reader.close()
    return json.loads(data_str)


def train():
    print("build vocab ...")
    idx_to_vocab, vocab_to_idx, _ = extract_character_vocab([DATA_PATH])

    # pickle idx_to_vocab and vocab_to_idx
    if IS_LOCAL:
        save_vocab_to_pickle(idx_to_vocab, os.path.join(BASE_MODEL_DIR, 'idx_to_vocab.pickle'))
        save_vocab_to_pickle(vocab_to_idx, os.path.join(BASE_MODEL_DIR, 'vocab_to_idx.pickle'))
    else:
        save_vocab_to_oss(idx_to_vocab, os.path.join(BASE_MODEL_DIR, 'idx_to_vocab.oss'))
        save_vocab_to_oss(vocab_to_idx, os.path.join(BASE_MODEL_DIR, 'vocab_to_idx.oss'))

    with tf.Graph().as_default() as graph:
        dataset = Dataset([DATA_PATH], batch_size=BATCH_SIZE, num_epoch=NUM_EPOCH, num_field=3)

        seq2seq_model = Seq2SeqModel()
        train_op, _ = seq2seq_model.build_graph(vocab_to_idx)
        loss = seq2seq_model.loss

        summary_op = tf.summary.merge_all()
        summary_writer = tf.summary.FileWriter(os.path.join(BASE_MODEL_DIR, 'log'), graph=graph)

        session = tf.Session()
        session.run(tf.global_variables_initializer())

        for step in range(MAX_ITERATION):
            pad_sources_batch, pad_targets_batch, source_batch_length, target_batch_length = get_batches(
                dataset=dataset,
                vocab_to_idx=vocab_to_idx
            )

            if pad_sources_batch is None:
                break

            feed_dict = {
                seq2seq_model.inputs: pad_sources_batch,
                seq2seq_model.targets: pad_targets_batch,
                seq2seq_model.source_sequence_length: source_batch_length,
                seq2seq_model.target_sequence_length: target_batch_length,
                seq2seq_model.max_target_sequence_length: max(target_batch_length),
                seq2seq_model.keep_prob: 0.5,
            }

            _, _loss = session.run( [train_op, loss], feed_dict=feed_dict)

            if step % 5 == 0:
                print('Iter %d, loss %f' % (step, _loss))

            if step % 100 == 0:
                summary_str = session.run(summary_op, feed_dict=feed_dict)
                summary_writer.add_summary(summary_str, step)

            if step % 500 == 0 or iter == MAX_ITERATION - 1:
                valid_pad_sources_batch, \
                valid_pad_targets_batch, \
                valid_source_batch_length, \
                valid_target_batch_length = get_batches(
                    dataset=dataset,
                    vocab_to_idx=vocab_to_idx
                )
                _loss = session.run(
                    loss,
                    feed_dict={
                        seq2seq_model.inputs: valid_pad_sources_batch,
                        seq2seq_model.targets: valid_pad_targets_batch,
                        seq2seq_model.source_sequence_length: valid_source_batch_length,
                        seq2seq_model.target_sequence_length: valid_target_batch_length,
                        seq2seq_model.max_target_sequence_length: max(valid_target_batch_length),
                        seq2seq_model.keep_prob: 1,
                    })
                print('Iter %d,  valid loss %f' % (step, _loss))

        inputs = {
            'x': seq2seq_model.inputs,
            'input_length': seq2seq_model.source_sequence_length,
            'max_target_length': seq2seq_model.max_target_sequence_length,
            'keep_prob': seq2seq_model.keep_prob,
            'num_input': seq2seq_model.num_sequences_to_decode
        }
        outputs = {
            'y': seq2seq_model.inference_logits
        }

        save_model(session, inputs=inputs, outputs=outputs, saved_model_dir=os.path.join(BASE_MODEL_DIR, 'seq2seq_attention'))


def predict(sentences):
    if IS_LOCAL:
        idx_to_vocab = load_vocab_from_pickle(os.path.join(BASE_MODEL_DIR, 'idx_to_vocab.pickle'))
        vocab_to_idx = load_vocab_from_pickle(os.path.join(BASE_MODEL_DIR, 'vocab_to_idx.pickle'))
    else:
        idx_to_vocab = load_vocab_from_oss(os.path.join(BASE_MODEL_DIR, 'idx_to_vocab.oss'))
        vocab_to_idx = load_vocab_from_oss(os.path.join(BASE_MODEL_DIR, 'vocab_to_idx.oss'))

    MODEL_NAME = 'seq2seq_attention'

    session = tf.Session()
    meta_graph_def = tf.saved_model.loader.load(
        sess=session,
        tags=[tf.saved_model.tag_constants.SERVING],
        export_dir=os.path.join(BASE_MODEL_DIR, MODEL_NAME)
    )
    signature = meta_graph_def.signature_def

    # input tensor name
    input_tensor_names = signature[tf.saved_model.signature_constants.DEFAULT_SERVING_SIGNATURE_DEF_KEY].inputs
    x_tensor_name = input_tensor_names['x'].name
    input_length_tensor_name = input_tensor_names['input_length'].name
    max_target_length_tensor_name = input_tensor_names['max_target_length'].name
    keep_prob_tensor_name = input_tensor_names['keep_prob'].name
    num_input_tensor_name = input_tensor_names['num_input'].name

    y_tensor_name = signature[tf.saved_model.signature_constants.DEFAULT_SERVING_SIGNATURE_DEF_KEY].outputs['y'].name

    # get tensor by name
    func = session.graph.get_tensor_by_name
    x = func(x_tensor_name)
    input_length = func(input_length_tensor_name)
    max_target_length = func(max_target_length_tensor_name)
    keep_prob = func(keep_prob_tensor_name)
    num_input = func(num_input_tensor_name)
    y = func(y_tensor_name)

    def source_to_seq(text):
        min_seq_len = 7
        if not IS_LOCAL:
            text = text.decode('utf-8')

        return [vocab_to_idx.get(char, vocab_to_idx['<UNK>']) for char in text if _is_chinese_char(char)] +\
               [vocab_to_idx['<PAD>']]*(min_seq_len-len(text))

    texts = [source_to_seq(sentence) for sentence in sentences]
    texts = pad_sentence_batch(texts, vocab_to_idx['<PAD>'])
    outputs_logits = session.run(
        y,
        feed_dict={
            x: np.array(texts),
            input_length: [len(text) for text in texts],
            max_target_length: 10,
            keep_prob: 1.0,
            num_input: len(texts)
        }
    )

    for sentence, text, outputs_logit in zip(sentences, texts, outputs_logits):
        print('Original: {}'.format(' '.join([idx_to_vocab[str(idx)].encode('utf-8') for idx in text])))
        print('Target: {}'.format(' '.join([idx_to_vocab[str(idx)].encode('utf-8') for idx in outputs_logit if idx > 0 and idx != vocab_to_idx['<PAD>']])))
        print('==================================================================')


if __name__ == '__main__':
    train()
    predict(['欧式水晶红酒杯架酒架 倒挂双层水晶旋转高脚杯架香槟葡萄酒悬挂',
             '大脑布原创米色编织包草编水桶包日系斜挎包单价包复古文艺沙滩包',
             'Geekcook极客库 囧机器人DIY木质拼装搞怪卷纸巾抽盒创意男友礼物',
             '日本FANCL正品无添加美白淡斑美容液18ml亮白精华液3756孕妇可用',
             '霍客森时尚玻璃钢糖果椅子简约单人沙发新古典单人创意个性沙发椅',
             '包邮 澳洲新西兰进口comvita康维他天然麦卢卡manuka 10+蜂蜜500g'])



#!/bin/bash 

latex ML-zh.tex
dvipdfm ML-zh.dvi
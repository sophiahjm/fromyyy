#!/usr/bin/env python
# -*- coding: utf-8 -*-
# @Time    : 18/7/28 PM3:35
# @Author  : shaoguang.csg
# @File    : graph_metric.py

import numpy as np
from common.batch_reader import SimplyTableReader
from utils.logger import logger

from sklearn.linear_model import LogisticRegression
from sklearn.model_selection import cross_val_score


def link_prediction(model, session, table_name, selected_cols, vocab_to_idx):
    reader = SimplyTableReader(table_name, selected_cols, batch_size=1024)
    start_nodes_embedding, end_nodes_embedding, labels = [], [], []
    cnt = 0

    while True:
        lines = reader.next_batch()
        if lines is None:
            break
        start_nodes, end_nodes, label = lines.T

        start_nodes_idx = [vocab_to_idx[str(node)] for node in start_nodes]
        end_nodes_idx = [vocab_to_idx[str(node)] for node in end_nodes]

        start_nodes_embedding.append(model.get_embedding(sess=session, ids=start_nodes_idx))
        end_nodes_embedding.append(model.get_embedding(sess=session, ids=end_nodes_idx))
        labels.extend(label.tolist())

        cnt += lines.shape[0]
    logger.info("Totally loaded {} lines".format(cnt))

    edge_embedding = np.hstack((np.vstack(start_nodes_embedding), np.vstack(end_nodes_embedding)))
    labels = np.array(labels)
    sample_idx = list(range(edge_embedding.shape[0]))
    np.random.shuffle(sample_idx)
    edge_embedding, labels = edge_embedding[sample_idx], labels[sample_idx]

    model = LogisticRegression()
    scores = cross_val_score(model, edge_embedding, np.array(labels), cv=2, scoring='accuracy', n_jobs=4, verbose=1)
    logger.info('mean score: {}, score: {}'.format(np.mean(scores), scores))
    return np.mean(scores)


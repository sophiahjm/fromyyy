#!/usr/bin/env python
# -*- coding: utf-8 -*-
# @Time    : 18/10/3 PM2:52
# @Author  : shaoguang.csg
# @File    : distance.py

import tensorflow as tf


def cal_distance(x, y, distance_type, axis):
    """
    cal the distance between x and y
    :param x: a tensor with the size of nxk
    :param y: a tensor with the size of nxk
    :param distance_type
    :return: nx1
    """
    return funcs[distance_type](x, y, axis)


def _euclidean(x, y, axis):
    return tf.sqrt(tf.reduce_sum(tf.square(x-y), axis=axis))


def _cosine(x, y, axis):
    norm_x = tf.sqrt(tf.reduce_sum(tf.square(x), axis=axis)) # nx1
    norm_y = tf.sqrt(tf.reduce_sum(tf.square(y), axis=axis)) # nx1
    x_y = tf.reduce_sum(tf.multiply(x, y), axis=axis) # nx1
    return 1.0-x_y/(norm_x*norm_y)

funcs = {
    'euclidean': _euclidean,
    'cosine': _cosine
}

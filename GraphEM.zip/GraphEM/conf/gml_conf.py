#!/usr/bin/env python
# -*- coding: utf-8 -*-
# @Time    : 18/10/3 AM9:59
# @Author  : shaoguang.csg
# @File    : gml_conf.py

from conf.basic_conf import BasicConf


class GMLConf(BasicConf):
    def __init__(self, ):
        super(GMLConf, self).__init__()

    def parse_conf_file(self):
        self.model_type = self.param_json.get('model_type', 'second_order')
        self.distance_type = self.param_json.get('distance_type', 'euclidean')
        self.margin = float(self.param_json.get('margin', 0.5))
        self.max_neighbor = int(self.param_json.get('max_neighbor', 100))

    def check_param(self):
        pass
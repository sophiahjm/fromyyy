#!/usr/bin/env python
# -*- coding: utf-8 -*-
# @Time    : 18/7/10 AM11:17
# @Author  : shaoguang.csg
# @File    : layers.py

import tensorflow as tf
from tensorflow.contrib.framework.python.ops import variables
from tensorflow.python.ops import variable_scope
from tensorflow.contrib.layers.python.layers import embedding_ops as contrib_embedding_ops
from tensorflow.python.ops import embedding_ops
from tensorflow.python.ops.variables import PartitionedVariable

import numpy as np

from utils.logger import logger

global_names = globals()
global_names['_layer_name_list'] = []
global_names['name_reuse'] = True


class Layer(object):
    """
    Layer is a mixin class.
    Base layer for all kinds if neural network layers.
    Because each layer can keep track of the layer(s) feeding into it, a network's output can double
    as a handle to the full network.
    """

    def __init__(self, inputs=None, name='Layer'):
        """
        :param inputs:
        :param name:
        """
        self.inputs = inputs
        if (name in global_names['_layer_name_list']) and (global_names['name_reuse'] == False):
            pass
        else:
            self.name = name
            if name not in ['', ' ', None, False]:
                global_names['_layer_name_list'].append(name)

    def __str__(self):
        return 'Layer {}'.format(self.__class__.__name__)

    def print_params(self, details=False):
        """
        print all parameters info in the network
        :param details:
        :return:
       """
        for index, param in enumerate(self.all_params):
            if details:
                if isinstance(param, PartitionedVariable):
                    continue
                try:
                    logger.info("\tParam {:3}: {:15} (mean: {:<18}, median: {:<18}, std: {:<18})   {}"
                                .format(index, str(param.eval().shape), param.eval().mean(),
                                        np.median(param.eval()), param.eval().std(), param.name))
                except:
                    raise Exception("\tPrint params details after sess.run(tf.initialize_all_variables())"
                                    " or use network.print_params(False).")
            else:
                logger.info("\tParam {:3}: {:15}    {}".format(index, str(param.get_shape()), param.name))
        logger.info("\tNum of params: %d" % self.count_params())

    def print_layers(self):
        for index, layer in enumerate(self.all_layers):
            logger.info("Layer {0}, {1}".format(index, str(layer)))

    def count_params(self):
        """
        return the number of parameters in the network
        :return:
        """
        num = 0
        for param in self.all_params:
            num_tmp = 1
            for dim in param.get_shape():
                try:
                    dim = int(dim)
                except:
                    dim = 1
                if dim:
                    num_tmp *= dim
            num += num_tmp
        return num


class InputLayer(Layer):
    """
    InputLayer is the starting layer of a neural network.
    """
    def __init__(self, inputs=None, name ='input_layer'):
        super(InputLayer, self).__init__(inputs=inputs, name=name)
        logger.info("\tInstantiate InputLayer  %s: %s" % (self.name, inputs.get_shape()))
        self.outputs = inputs
        self.all_layers = []
        self.all_params = []
        self.all_dropout = {}


class EmbeddingLayer(Layer):
    """
    EmbeddingLayer maps id variable to a low-rank dense vector and is always the starting of a network
    """
    def __init__(self,
                 ids,
                 voc_size=None,
                 embed_dim=None,
                 initializer=None,
                 trainable=True,
                 reuse=None,
                 scope=None,
                 unique=False,
                 num_partition=None,
                 name="embedding_layer"):
        """

        :param ids: `[batch_size]` `Tensor` of type `int32` or `int64` with symbol ids.
        :param voc_size:
        :param embed_dim:
        :param initializer:
        :param trainable: If `True` also add variables to the graph collection GraphKeys.TRAINABLE_VARIABLES
        :param reuse: If `True`, variables inside the op will be reused
        :param scope: Optional string specifying the variable scope for the op, required if `reuse=True`.
        :param num_partition:
        :param name:
        """
        if not (reuse or (voc_size and embed_dim)):
            raise ValueError('Must specify vocab size and embedding dimension when not '
                             'reusing. Got vocab_size=%s and embed_dim=%s' % (voc_size, embed_dim))

        super(EmbeddingLayer, self).__init__(name=name)
        logger.info("\tInstantiate EmbeddingLayer  %s: voc_size=%d embed_dim=%d" % (self.name, voc_size, embed_dim))

        with variable_scope.variable_scope(
                scope, 'embedding_matrix', [ids], reuse=reuse):
            shape = [voc_size, embed_dim]
            if reuse and voc_size is None or embed_dim is None:
                shape = None
            self.embeddings = variables.model_variable(
                'embeddings',
                shape=shape,
                initializer=initializer,
                trainable=trainable,
                partitioner=tf.min_max_variable_partitioner(
                    max_partitions=num_partition if num_partition is not None else 1,
                    min_slice_size=256 << 10
                )
            )

            if unique:
                self.outputs = contrib_embedding_ops.embedding_lookup_unique(self.embeddings, ids)
            else:
                self.outputs = embedding_ops.embedding_lookup(self.embeddings, ids)
        self.all_layers = [self.outputs]
        self.all_params = [self.embeddings]
        self.all_dropout = {}


class DenseLayer(Layer):
    """
    FC layer
    """
    def __init__(self, layer, num_units=128, act_func=tf.nn.relu,
                 w_init=tf.random_normal_initializer(stddev=0.01),
                 b_init=tf.constant_initializer(value=0.0),
                 name='dense_layer'):
        super(DenseLayer, self).__init__(name=name)
        self.inputs = layer.outputs

        assert self.inputs.get_shape().ndims == 2, 'The input dimension must be rank 2, please reshape or flatten it'

        input_dim = self.inputs.get_shape().as_list()[-1]
        self.num_units = num_units
        logger.info("\tInstantiate DenseLayer  %s: %d %s" % (self.name, num_units, act_func.__name__))

        with tf.variable_scope(name):
            W = tf.get_variable(name='weight', shape=(input_dim, self.num_units), initializer=w_init)
            if b_init:
                b = tf.get_variable(name='bias', shape=num_units, initializer=b_init)
                self.outputs = act_func(tf.matmul(self.inputs, W)+b)
            else:
                self.outputs = act_func(tf.matmul(self.inputs, W))

        self.all_layers = list(layer.all_layers)
        self.all_params = list(layer.all_params)
        self.all_dropout = dict(layer.all_dropout)
        self.all_layers.extend([self.outputs])
        if b_init:
            self.all_params.extend([W, b])
        else:
            self.all_params.extend([W])


if __name__ == '__main__':

    def func(x):
        ids = dict()
        ids['a'] = tf.placeholder(tf.int32, [None, None], name='ids_a')
        ids['b'] = tf.placeholder(tf.int32, [None, None], name='ids_b')

        embed_a = EmbeddingLayer(ids['a'], voc_size=10, embed_dim=2).outputs
        embed_b = EmbeddingLayer(ids['b'], voc_size=10, embed_dim=2).outputs

    #    con_embed = tf.reduce_mean(tf.concat([embed_a, embed_b], axis=1), axis=1)
        if x > 0:
            c = tf.multiply(embed_a, embed_b)
            return ids, embed_a, embed_b, c
        return ids, embed_a, embed_b

    a = -1
    ops = func(a)

    sess = tf.Session()

    feed_dict = {}
    x = [[1,3],[1,2],[3,11]]
    for k, v in ops[0].items():
        feed_dict[v] = x

    sess.run(tf.global_variables_initializer())
    if a > 0:
        a,b,c = sess.run([ops[1], ops[2], ops[3]], feed_dict=feed_dict)
        print(a)
        print(b)
        print(c)
    else:
        a,b = sess.run([ops[1], ops[2]], feed_dict=feed_dict)
        print(a)
        print(b)

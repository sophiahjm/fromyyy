#!/usr/bin/env python
# -*- coding: utf-8 -*-
# @Time    : 17/12/7 PM7:41
# @Author  : shaoguang.csg
# @File    : model_core.py

from parse_conf import (ModelConf, DataConf)
from utils.logger import logger
from utils.tensorflow_helper import get_available_devices
from utils.system_op import is_contain_array
from utils.metrics import (
    streaming_classification_metrics,
    streaming_regression_metrics
)
from model.multi_task_estimator import MultiTaskEstimator

from functools import partial
import tensorflow as tf
from tensorflow.python.feature_column.feature_column import *


tf.logging.set_verbosity(tf.logging.INFO)


class ModelCore(object):
    """
    The core of MTL
    """
    def __init__(self, data_conf: DataConf, model_conf: ModelConf):
        self._data_conf = data_conf
        self._model_conf = model_conf
        self._multi_tasks = model_conf.multi_tasks
        self._monitors = None

        logger.info("Start to build the model ...")
        self._build_feature_columns()

        self._run_config = tf.contrib.learn.RunConfig(
            save_summary_steps=100,
            save_checkpoints_steps=self._model_conf.save_checkpoint_interval,
            session_config=self._get_session_config(),
            keep_checkpoint_max=5
        )

        self._model = MultiTaskEstimator(
            multi_tasks=self._multi_tasks,
            model_dir=self._model_conf.model_dir,
            weight_column_name=None,
            optimizer=self._get_optimizer(),  # TODO
            learning_rate=self._model_conf.base_lr,
            dropout=self._model_conf.dropout_ratio,
            beta=self._model_conf.beta,
            config=self._run_config,
            learning_rate_decay_fn=self.get_learning_rate_decay_fn() # TODO
        )
        self._metrics = self._get_metrics()

        logger.info(self._model)

    def fit(self, input_fn, steps):
        logger.info("train the model ...") # TODO set monitors inner class
        self._model.fit(
            input_fn=input_fn,
            steps=steps,
            monitors=self._monitors
        )
        return self

    def partial_fit(self, input_fn, steps):
        logger.info("train the model ...")
        self._model.partial_fit(
            input_fn=input_fn,
            steps=steps,  #
            monitors=self._monitors
        )
        return self

    def evaluate(self, input_fn, name=None):
        logger.info("do the evaluation ...")
        return self._model.evaluate(
            input_fn=input_fn,
            steps=1,
            metrics=self._metrics,
            name=name
        )

    def predict(self, input_fn):
        logger.info("do the prediction ...")
        pass

    def add_monitor(self, monitor):
        if self._monitors is None:
            self._monitors = []
        self._monitors.append(monitor)

    def export_saved_model(self):
        pass # TODO

    def load_model(self):
        pass # TODO

    def get_weight(self):
        weight = {}
        for var_name in self._model.get_variable_names():
            if var_name.endswith('weights'):
                weight[var_name] = self._model.get_variable_value(var_name)
        return weight

    def _get_metrics(self):
        metrics = {}
        for task_name, task in self._multi_tasks.get_tasks().items():
            if task.task_type == 'classification':
                metrics[('accuracy', task_name+'_head')] = streaming_classification_metrics['accuracy']
                metrics[('recall', task_name + '_head')] = streaming_classification_metrics['recall']
                metrics[('precision', task_name + '_head')] = streaming_classification_metrics['precision']
            elif task.task_type == 'regression':
                metrics[('mae', task_name+'_head')] = streaming_regression_metrics['mae']
                metrics[('mse', task_name+'_head')] = streaming_regression_metrics['mse']
                metrics[('rmse', task_name+'_head')] = streaming_regression_metrics['rmse']
                metrics[('mape', task_name+'_head')] = streaming_regression_metrics['mape']
            else:
                raise TypeError("Unsupported task type")
        return metrics

    def _get_session_config(self):
        gpu_devices, _ = get_available_devices()
        if len(gpu_devices) == 0:
            logger.warning("No GPU found, using CPU")
            session_config = tf.ConfigProto(
                device_count={
                    'CPU': self._model_conf.num_cpu_core
                },
                intra_op_parallelism_threads=self._model_conf.num_threads_per_core,
                inter_op_parallelism_threads=self._model_conf.num_threads_per_core,
                log_device_placement=False
            )
        else:
            logger.info("GPU: {} found".format(gpu_devices))
            session_config = tf.ConfigProto(log_device_placement=False, allow_soft_placement=True)
        return session_config

    def get_learning_rate_decay_fn(self):
        if self._model_conf.lr_policy == 'fixed':
            return None
        elif self._model_conf.lr_policy == 'step':
            lr_decay_func = partial(
                tf.train.exponential_decay,
                decay_steps=self._model_conf.step_size,
                decay_rate=0.95,
                staircase=True
            )
            return lr_decay_func
        else:
            logger.error("Unsupport lr policy: %s" % self._model_conf.lr_policy)
            return None

    def _get_optimizer(self, optimizer_type='proximal_adagrad'):
        if optimizer_type == 'ftrl':
            optimizer = partial(
                tf.train.FtrlOptimizer,
                l1_regularization_strength=self._model_conf.alpha,
                l2_regularization_strength=self._model_conf.beta
            )
        elif optimizer_type == 'sgd':
            optimizer = tf.train.GradientDescentOptimizer
        elif optimizer_type == 'momentum':
            optimizer = partial(
                tf.train.MomentumOptimizer,
                momentum=0.9
            )
        elif optimizer_type == 'adam':
            optimizer = tf.train.AdamOptimizer
        elif optimizer_type == 'proximal_adagrad':
            optimizer = partial(
                tf.train.ProximalAdagradOptimizer,
                l1_regularization_strength=self._model_conf.alpha,
                l2_regularization_strength=self._model_conf.beta
            )
        else:
            logger.error("Unsupport optimizer type")
            optimizer = None
        return optimizer

    def _build_feature_columns(self):
        multi_category_feature_columns = {}
        continuous_feature_columns = {}
        self._feature_columns = {}

        if self._data_conf.multi_hot_columns is not None :
            for column in self._data_conf.multi_hot_columns:
                feature_column = indicator_column(
                    categorical_column_with_vocabulary_list(
                        column,
                        self._data_conf.multi_hot_columns[column],
                        dtype=tf.string
                    )
                )
                if column not in self._feature_columns:
                    self._feature_columns[column] = [feature_column]
                else:
                    self._feature_columns[column].append(feature_column)

        if self._data_conf.multi_category_columns is not None:
            for column, size in self._data_conf.multi_category_columns.items():
                feature_column = categorical_column_with_hash_bucket(column, hash_bucket_size=size)
                multi_category_feature_columns[column] = feature_column
                if column not in self._feature_columns:
                    self._feature_columns[column] = [feature_column]
                else:
                    self._feature_columns[column].append(feature_column)

        if self._data_conf.continuous_columns is not None:
            for column in self._data_conf.continuous_columns:
                feature_column = numeric_column(column)
                continuous_feature_columns[column] = feature_column
                if column not in self._feature_columns:
                    self._feature_columns[column] = [feature_column]
                else:
                    self._feature_columns[column].append(feature_column)

        if self._data_conf.crossed_columns is not None:
            for column in self._data_conf.crossed_columns:
                column, hash_bucket_size = tuple(column[:-1]), column[-1]
                feature_column = crossed_column(column, hash_bucket_size=hash_bucket_size)
                if column not in self._feature_columns:
                    self._feature_columns[column] = [feature_column]
                else:
                    self._feature_columns[column].append(feature_column)

        if self._data_conf.bucketized_columns is not None:  # columns to bucket must be in continuous_feature_columns
            for column, boundary in self._data_conf.bucketized_columns.items():
                if column not in continuous_feature_columns:
                    feature_column = bucketized_column(numeric_column(column), boundaries=boundary)
                else:
                    feature_column = bucketized_column(continuous_feature_columns[column], boundaries=boundary)

                if column not in self._feature_columns:
                    self._feature_columns[column] = [feature_column]
                else:
                    self._feature_columns[column].append(feature_column)

        if self._data_conf.embeding_columns is not None and len(multi_category_feature_columns) > 0:
            for column in self._data_conf.embeding_columns:
                if column in continuous_feature_columns:
                    logger.error("embedding columns must be categorial, {} is continuous.so ignored".format(column))
                    continue
                if column not in multi_category_feature_columns:
                    feature_column = embedding_column(
                        categorical_column_with_hash_bucket(column, hash_bucket_size=1000),
                        dimension=self._model_conf.embedding_dimension
                    )
                else:
                    feature_column = embedding_column(
                        multi_category_feature_columns[column],
                        dimension=self._model_conf.embedding_dimension
                    )

                if column not in self._feature_columns:
                    self._feature_columns[column] = [feature_column]
                else:
                    self._feature_columns[column].append(feature_column)

        # set common part feature columns
        feature_columns = []
        for feature in self._multi_tasks.common_features:
            feature_columns.extend(self._feature_columns[feature])
        self._multi_tasks.common_feature_columns = feature_columns

        # set feature columns for each task, considering all kinds of features
        multi_tasks = self._multi_tasks.get_tasks()
        for task_name, task in multi_tasks.items():
            feature_columns = []
            for feature in self._feature_columns:
                if is_contain_array(task.features, feature):
                    feature_columns.extend(self._feature_columns[feature])
            task.feature_columns = feature_columns


if __name__ == '__main__':
    data_conf = DataConf()
    model_conf = ModelConf()
    model_core = ModelCore(data_conf, model_conf)
    print(model_core._multi_tasks.common_feature_columns)
    for task_name, task in model_core._multi_tasks.get_tasks().items():
        print(task_name, task.feature_columns)
#!/usr/bin/env python
# -*- coding: utf-8 -*-
# @Time    : 18/7/10 AM11:13
# @Author  : shaoguang.csg
# @File    : basic_model.py


import tensorflow as tf
from abc import ABCMeta, abstractmethod
from utils.logger import logger


class BasicModel(object):

    __metaclass__ = ABCMeta

    def __init__(self, conf):
        self.train_op = None
        self.loss = None
        self.conf = conf

    @abstractmethod
    def build_graph(self):
        raise NotImplementedError

    def build_optimizer(self, *args, **kwargs):
        if self.conf.l2_regularize :
            l2_costs = []
            [l2_costs.append(tf.nn.l2_loss(var)) for var in tf.trainable_variables() if var.op.name.find(r'weight') > 0 or var.op.name.find(r'embedding') > 0]
            if len(l2_costs) > 0:
                for _ in l2_costs:
                    logger.info(_)

                self.l2loss = self.conf.beta*tf.add_n(l2_costs)
                self.loss += self.l2loss
            else:
                logger.info("length of l2 costs is zero")

        global_step = tf.Variable(initial_value=0, name='global_step', trainable=False)

        if self.conf.optimizer == 'adam':
            optimizer = tf.train.AdamOptimizer(learning_rate=self.conf.base_lr)  # FIXME may case perforamce problem, need to fix
        elif self.conf.optimizer == 'momentum':
            optimizer = tf.train.MomentumOptimizer(learning_rate=self.conf.base_lr, momentum=0.9)
        elif self.conf.optimizer == 'adelta':
            optimizer = tf.train.AdadeltaOptimizer(learning_rate=self.conf.base_lr)
        else:
            optimizer = tf.train.GradientDescentOptimizer(learning_rate=self.conf.base_lr)

        logger.info("trainable vars: ")
        for var in tf.trainable_variables():
            logger.info(var.op.name)

        gradients = optimizer.compute_gradients(loss=self.loss)  # do gradients clipping
        gradients = [(tf.clip_by_value(grad, -5.0, 5.0), var) for grad, var in gradients if grad is not None]
        self.train_op = optimizer.apply_gradients(gradients, global_step=global_step)

        tf.summary.scalar('loss', self.loss)
        if self.conf.l2_regularize :
            tf.summary.scalar('l2loss', self.l2loss)
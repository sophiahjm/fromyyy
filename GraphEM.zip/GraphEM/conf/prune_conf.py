#!/usr/bin/env python
# -*- coding: utf-8 -*-
# @Time    : 18/7/4 PM5:22
# @Author  : shaoguang.csg
# @File    : prune_conf.py

from conf.basic_conf import BasicConf


class PruneConf(BasicConf):

    def __init__(self):
        super(PruneConf, self).__init__()
        pass

    def parse_conf_file(self):
        self.lambd = float(self.param_json.get('lambda', 0.01))
        self.proximity_latent_size = int(self.param_json.get('proximity_latent_size', 64))
        self.proximity_hidden_size = int(self.param_json.get('proximity_hidden_size', 128))
        self.rank_hidden_size = int(self.param_json.get('rank_hidden_size', 128))

    def check_param(self):
        pass

if __name__ == '__main__':
    pruneConf = PruneConf()
    print(pruneConf.embed_size)

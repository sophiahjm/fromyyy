# DLAPP

Do some abstractions and encapsulations for tensorflow to easily use it. In this part, I make lots of references from tensorlayer. Appreciate DongHao's great work.

#!/usr/bin/env python
# -*- coding: utf-8 -*-
# @Time    : 18/5/13 AM10:52
# @Author  : shaoguang.csg
# @File    : extract_text_info.py

import tensorflow as tf
import string
from collections import Counter

#from TextSum.conf import BATCH_SIZE, IS_LOCAL
from conf import BATCH_SIZE, IS_LOCAL


class Dataset(object):

    def __init__(self, filename_list, batch_size, num_epoch, num_field, is_shuffle=True):

        self.read_op = self._create_read_op(filename_list, batch_size, num_epoch, num_field, is_shuffle)
        self._init_reader()

    def _create_read_op(self, filename_list, batch_size, num_epoch, num_field, is_shuffle):
        with tf.variable_scope('data_reader'):
            filename_queue = tf.train.string_input_producer(
                filename_list,
                num_epochs=num_epoch,
                shuffle=is_shuffle
            )

        if IS_LOCAL:
            reader = tf.TextLineReader()
        else:
            reader = tf.TableRecordReader(csv_delimiter=',')
        key, value = reader.read_up_to(filename_queue, num_records=batch_size)
        if is_shuffle:
            value = tf.train.shuffle_batch(
                [value],
                batch_size=batch_size,
                capacity=80000,
                enqueue_many=True,
                num_threads=32,
                min_after_dequeue=2000
            )
        cols = tf.decode_csv(
            value,
            record_defaults=self._get_default_record(num_field),
            use_quote_delim=False,
            field_delim=u'\u0001' if IS_LOCAL else ','
        )
        read_op = tf.stack(cols, axis=1)
        return read_op

    def _init_reader(self):
        gpu_options = tf.GPUOptions(allow_growth=True)
        config = tf.ConfigProto(
            gpu_options=gpu_options,
            allow_soft_placement=True,
#            log_device_placement=True
        )
        self.sess = tf.Session(config=config)
        init_op = [tf.global_variables_initializer(), tf.local_variables_initializer()]
        self.sess.run(init_op)

        self.coord = tf.train.Coordinator()
        self.threads = tf.train.start_queue_runners(sess=self.sess, coord=self.coord)

    def stop(self):
        self.coord.request_stop()
        self.coord.join(self.threads)
        self.sess.close()

    def next_batch(self):
        try:
            lines = self.sess.run(self.read_op)
            return lines
        except Exception as e:
            print('next batch iteration finished')
            self.stop()

    @staticmethod
    def _get_default_record(num_field):
        return [['']]*num_field


def read_text_line(filename_list, num_epoch, batch_size):
    data = tf.data.TextLineDataset(filenames=filename_list)
    data = data.shuffle(buffer_size=1000).repeat(num_epoch).batch(batch_size)
    iterator = data.make_one_shot_iterator()
    next_element = iterator.get_next()
    return next_element


def read_element(next_element):
    sess = tf.Session()
    print(sess.run(next_element))


def _is_chinese_char(char):
    return u'\u4e00' <= char <= u'\u9fff'


def extract_character_vocab(filename_list):
    special_characters = ['<PAD>', '<UNK>', '<GO>', '<EOS>']
    vocab_freq = {}
    cnt = 0

    def _parse_lines(lines):
        for line in lines:
            for char in (line[1]+line[2]).decode('utf-8'):
                if not _is_chinese_char(char):
                    continue
                if char in vocab_freq:
                    vocab_freq[char] += 1
                else:
                    vocab_freq[char] = 1

    dataset = Dataset(filename_list, batch_size=128, num_epoch=1, num_field=3)
    while True:
        lines = dataset.next_batch()
        if lines is None:
            break
        _parse_lines(lines)
        cnt += lines.shape[0]
        if cnt % 10000 == 0:
            print('Parsed cnt %d' % cnt)

    print('Total vocab size: %d' % len(vocab_freq))
    print('Greater than 10:  %d' % len([k for k, v in vocab_freq.items() if v > 10]))
    print('Greater than 20:  %d' % len([k for k, v in vocab_freq.items() if v > 20]))
    print('Greater than 30:  %d' % len([k for k, v in vocab_freq.items() if v > 30]))

    counter = Counter(vocab_freq)
    vocab_freq = dict(counter.most_common(n=3000))

    idx_to_vocab = {idx: word for idx, word in enumerate(list(vocab_freq.keys())+special_characters)}
    vocab_to_idx = {word: idx for idx, word in idx_to_vocab.items()}

    return idx_to_vocab, vocab_to_idx, vocab_freq



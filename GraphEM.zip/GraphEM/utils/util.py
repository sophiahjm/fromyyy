#!/usr/bin/env python
# -*- coding: utf-8 -*-
# @Time    : 18/7/27 AM11:18
# @Author  : shaoguang.csg
# @File    : utils.py

import tensorflow as tf
import timeit

from utils.logger import logger

from functools import reduce

def clock(func):
    def clocked(*args, **kwargs):
        t0 = timeit.default_timer()
        result = func(*args, **kwargs)
        elapsed = timeit.default_timer() - t0
        name = func.__name__
        logger.info('[cost %0.8fs] %s' % (elapsed, name))
        return result
    return clocked


def count_param():
    size = lambda v: reduce(lambda x, y: x*y, v.get_shape().as_list())
    for v in tf.trainable_variables():
        logger.info("var_name: {}, device: {}, shape: {}".format(v.name, v.device, size(v)))
    logger.info("Total param num: {}".format(sum(size(v) for v in tf.trainable_variables())))

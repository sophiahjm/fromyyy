#!/usr/bin/env python
# -*- coding: utf-8 -*-
# @Time    : 18/7/4 PM5:05
# @Author  : shaoguang.csg
# @File    : basic_conf.py

import tensorflow as tf
from abc import ABCMeta, abstractmethod
import json
import sys

from utils.logger import logger


tf.app.flags.DEFINE_string("tables", "", "tables info")  # -Dtables
tf.app.flags.DEFINE_string("outputs", "", "outputs tables info")  #  -Doutputs
tf.app.flags.DEFINE_string("checkpointDir", "", "checkpoints dir")  #  -DcheckpointDir
tf.app.flags.DEFINE_string('param_json', '{}', 'A json string to store extra hyper-params') # -Dparam

tf.app.flags.DEFINE_integer("task_index", None, "Worker task index")  # -Dcluster="{\"ps\":{\"count\":1},\"worker\":{\"count\":3}}"
tf.app.flags.DEFINE_string("ps_hosts", "","ps hosts")
tf.app.flags.DEFINE_string("worker_hosts", "", "worker hosts")
tf.app.flags.DEFINE_string("job_name", None, "job name: worker or ps")

FLAGS = tf.app.flags.FLAGS


class BasicConf(object):

    __metaclass__ = ABCMeta

    IS_LOCAL = False

    def __init__(self):
        tables = FLAGS.tables.split(',')
        if len(tables) < 2:
            logger.info("tables: <edge_table> <node_table> <...>")
            sys.exit(-1)

        self.edge_table = tables[0]
        self.node_table = tables[1]
        if len(tables) > 2:
            self.eval_table = tables[2]
        else:
            self.eval_table = None

        self.ps_hosts = FLAGS.ps_hosts.split(',')
        self.worker_hosts = FLAGS.worker_hosts.split(',')
        self.num_ps = len(self.ps_hosts) if len(self.ps_hosts) > 0 else 1
        self.num_worker = len(self.worker_hosts) if len(self.worker_hosts) > 0 else 1
#        self.task_index = int(FLAGS.task_index)
        self.job_name = FLAGS.job_name

        self.print_job_info()
        logger.info(FLAGS.param_json)
        self.param_json = json.loads(FLAGS.param_json)

        self.embedding_result_table = FLAGS.outputs.strip().strip(',').split(',')
        self.checkpoint_dir = None if FLAGS.checkpointDir == "" else FLAGS.checkpointDir

        self.parse_basic_conf_file()
        self.parse_conf_file()
        self.check_param()

    def parse_basic_conf_file(self):
        """
         All models must have these configurations
        :return:
        """
        self.start_node_col_name = self.param_json.get('start_node_col_name')
        self.end_node_col_name = self.param_json.get('end_node_col_name')

        self.node_col_name = self.param_json.get('node_col_name')  # node_id in attribute table
        self.attribute_cols = self.param_json.get('attr_cols')  # attr cols config
        if self.attribute_cols is None:
            self.has_attribute = False
        else:
            self.has_attribute = True
            self.indegree_col = None
            self.outdegree_col = None
            self.attribute_id_cols = []
            self.attribute_text_col = None
            self.neighbors_col = None
            for col in self.attribute_cols:
                if col.get('col_type') == 'id':  # is attr
                    self.attribute_id_cols.append(col)
                elif col.get('col_type') == 'text':  # text attr, only have one col of text attr
                    self.attribute_text_col = col
                elif col.get('col_type') == 'indegree':
                    self.indegree_col = col
                elif col.get('col_type') == 'outdegree':
                    self.outdegree_col = col
                elif col.get('col_type') == 'neighbors':
                    self.neighbors_col = col
                else:
                    logger.error("Not supported col_type: {} yet".format(col.get('col_type')))
                    sys.exit(-1)

        self.num_edge = int(self.param_json.get('num_edge', -1))
        self.alpha = int(self.param_json.get('alpha', 5)) # negative sample size
        self.embed_size = int(self.param_json.get('embed_size', 128))
        self.max_iteration = int(self.param_json.get('max_iteration', 5))
        self.batch_size = int(self.param_json.get('batch_size', 1024))
        self.base_lr = float(self.param_json.get('base_lr', 0.01))
        self.decay_steps = float(self.param_json.get('decay_steps', 10000))
        self.l2_regularize = self.param_json.get('l2_regularize', 'True') == 'True'
        self.beta = float(self.param_json.get('beta', 0.0001))
        self.optimizer = self.param_json.get('optimizer', 'adam')

    @abstractmethod
    def parse_conf_file(self):
        raise NotImplementedError()


    @abstractmethod
    def check_param(self):
        raise NotImplementedError()

    def print_job_info(self):
        logger.info("PS hosts: {}".format(self.ps_hosts))
        logger.info("Worker hosts: {}".format(self.worker_hosts))
#        logger.info("Job name: {}, Task index: {}".format(self.job_name, self.task_index))
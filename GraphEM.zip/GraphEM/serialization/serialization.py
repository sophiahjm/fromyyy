#!/usr/bin/env python
# -*- coding: utf-8 -*-
# @Time    : 18/7/21 PM5:33
# @Author  : shaoguang.csg
# @File    : serialization.py

import tensorflow as tf
import tensorflow.contrib.lookup as lookup
import numpy as np
from collections import Counter
import re
from multiprocessing import (Pool, cpu_count)
from multiprocessing.dummy import Pool as ThreadPool

from common.batch_reader import SimplyTableReader, SimpleCSVReader
from conf.prune_conf import PruneConf
from utils.logger import logger
from utils.util import clock


@clock
def node_attr_id_mapping(conf):
    special_key = '<UNK>'
    num_id_cols, num_text_col = 0, 0
    selected_cols = [conf.node_col_name]
    num_id_cols = len(conf.attribute_id_cols)
    if num_id_cols > 0:
        selected_cols += [id_col.get('col_name') for id_col in conf.attribute_id_cols]
    if conf.attribute_text_col is not None:
        selected_cols += [conf.attribute_text_col.get('col_name')]
        num_text_col = 1
    selected_cols_str = ','.join(selected_cols)

    node_set = set()
    id_counters = [Counter() for _ in range(num_id_cols)]
    word_counter = Counter()

    def _parse_lines(lines):
        node_set.update(lines[:, 0]) # add node
        if num_id_cols > 0:
            [id_counters[idx].update(Counter(lines[:, idx+1])) for idx in range(num_id_cols)]
        if num_text_col > 0:
            [word_counter.update(re.split(' +', line.decode('utf-8'))) for line in lines[:, -1]]

    logger.info("num_id_cols: {}, num_text_col: {}".format(num_id_cols, num_text_col))
    logger.info("node table: {}".format(conf.node_table))
    logger.info("selected cols: {}".format(selected_cols_str))

    num_line = 0
    if PruneConf.IS_LOCAL:
        dataset = SimpleCSVReader(conf.node_table, selected_cols_str, batch_size=4096)
    else:
        dataset = SimplyTableReader(conf.node_table, selected_cols_str, batch_size=4096)
    while True:
        lines = dataset.next_batch()
        if lines is None:
            break
        _parse_lines(lines)
        num_line += lines.shape[0]
        if num_line > 0 and num_line % 81920 == 0:
            logger.info("Parsed {} lines".format(num_line))
    logger.info("Totally parsed {} lines".format(num_line))

    word_counter.pop('', -1)   # pop space word

    logger.info("filtering low frequency items ... ")
    attr_ids = {}
    words = []
    if num_id_cols > 0:
        for idx in range(num_id_cols):
            min_count = int(conf.attribute_id_cols[idx].get('min_count', 100))
            attr_name = conf.attribute_id_cols[idx].get('col_name')
            logger.info("\tprocessing {} ...".format(attr_name))
            attr_ids[attr_name] = [id_ for id_, cnt in id_counters[idx].items() if cnt > min_count]
    if num_text_col > 0:
        min_count = int(conf.attribute_text_col.get('min_count', 100))
        words = [word for word, cnt in word_counter.items() if cnt > min_count]

    logger.info("idx_to_vocab and vocab_to_idx ...")
    idx_to_vocab, vocab_to_idx = dict(), dict()
    idx_to_vocab['node'] = {idx: node_id for idx, node_id in enumerate(node_set)}  # this step cost too much time, need to fix
    vocab_to_idx['node'] = {word: idx for idx, word in idx_to_vocab['node'].items()} # this step cost too much time, need to fix
    if num_id_cols > 0:
        for attr_name in attr_ids.keys():
            logger.info('\tprocessing {} ...'.format(attr_name))
            idx_to_vocab[attr_name] = {idx: attr_id for idx, attr_id in enumerate(attr_ids[attr_name]+[special_key])}
            vocab_to_idx[attr_name] = {word: idx for idx, word in idx_to_vocab[attr_name].items()}

    if num_text_col > 0:
        idx_to_vocab['text'] = {idx: word for idx, word in enumerate(words+[special_key])}
        vocab_to_idx['text'] = {word: idx for idx, word in idx_to_vocab['text'].items()}

    _print_attr_summary(vocab_to_idx)

    return idx_to_vocab, vocab_to_idx


def _print_attr_summary(vocab_to_idx):
    logger.info("\nAttribute summary: ")
    for key, value in vocab_to_idx.items():
        logger.info("{}: {}".format(key, len(value)))


def _get_idx_tensor_from_list(vocab_list):
    assert isinstance(vocab_list, list), 'vocab_list must be type of list'
    vocab_to_idx_mapping = tf.constant(vocab_list)
    vocab_to_idx_table = lookup.index_table_from_tensor(vocab_to_idx_mapping)
    idx_to_vocab_table = lookup.index_to_string_table_from_tensor(vocab_to_idx_mapping)
    return vocab_to_idx_table, idx_to_vocab_table


@clock
def node_attr_2_idx(conf, vocab_to_idx):
    """
    node_id, out_degree, in_degree, id_attr1, id_attr2,..., text_attr
    :param conf:
    :return:
    """
    special_key = '<UNK>'

    num_id_cols, num_text_col = 0, 0
    selected_cols = [conf.node_col_name]
    num_id_cols = len(conf.attribute_id_cols)
    selected_cols += [conf.outdegree_col.get('col_name'), conf.indegree_col.get('col_name')]
    if num_id_cols > 0:
        selected_cols += [id_col.get('col_name') for id_col in conf.attribute_id_cols]
    if conf.attribute_text_col is not None:
        selected_cols += [conf.attribute_text_col.get('col_name')]
        num_text_col = 1
    if conf.neighbors_col is not None:
        selected_cols += [conf.neighbors_col.get('col_name')]

    selected_cols_str = ','.join(selected_cols)

    logger.info("num_id_cols: {}, num_text_col: {}".format(num_id_cols, num_text_col))
    logger.info("node table: {}".format(conf.node_table))
    logger.info("selected cols: {}".format(selected_cols_str))

    num_line = 0
    all_lines = []

    if PruneConf.IS_LOCAL:
        dataset = SimpleCSVReader(conf.node_table, selected_cols_str, batch_size=4096)
    else:
        dataset = SimplyTableReader(conf.node_table, selected_cols_str, batch_size=4096)
    while True:
        lines = dataset.next_batch()
        if lines is None:
            break
        all_lines.append(lines)
        num_line += lines.shape[0]

        if num_line % 81920 == 0:
            logger.info("Parsed {} lines".format(num_line))
    logger.info("Totally loaded {} lines".format(num_line))

    node_outin_degree = dict()
    node_attr_ids = {conf.attribute_id_cols[idx].get('col_name'):dict() for idx in range(num_id_cols)}
    node_text_ids = dict()
    node_neighbors = dict()
    all_lines = np.vstack(all_lines)

    num_line = 0
    for line in all_lines:
        key = line[0]  # key is original id
        node_outin_degree[key] = [float(_) for _ in line[1:3]]  # process degree
        next_index = 3
        if num_id_cols > 0: # process ids
            for idx in range(num_id_cols):
                attr_name = conf.attribute_id_cols[idx].get('col_name')
                id_value = vocab_to_idx[attr_name].get(line[idx+next_index], vocab_to_idx[attr_name].get(special_key))
                node_attr_ids[attr_name][key] = id_value
            next_index += num_id_cols

        if num_text_col > 0:  # process text
            words = re.split(' +', line[next_index].decode('utf-8'))
            words_idx = []
            [words_idx.append(vocab_to_idx['text'].get(word, vocab_to_idx['text'].get(special_key))) for word in words if word != '']
            node_text_ids[key] = words_idx
            next_index += 1

        if conf.neighbors_col is not None:
            node_neighbors[vocab_to_idx['node'].get(key)] = set([vocab_to_idx['node'].get(idx) for idx in line[next_index].split(',')])

        num_line += 1
        if num_line % 100000 == 0:
            logger.info("Parsed {} lines".format(num_line))
    logger.info("Totally parsed {} lines".format(num_line))

    return node_outin_degree, node_attr_ids, node_text_ids, node_neighbors


def save_vocab_to_oss():
    pass


def load_vocab_from_oss():
    pass

if __name__ == '__main__':
    import time

    start = time.time()
    prune_conf = PruneConf()
    idx_2_vocab, vocab_2_idx = node_attr_id_mapping(conf=prune_conf)
    end = time.time()
    logger.info("node_attr_id_mapping, time consumed:{}".format(end-start))

    start = time.time()
    node_outin_degree, node_attr_ids, node_text_ids = node_attr_2_idx(prune_conf, vocab_2_idx)
    end = time.time()
    logger.info("node_attr_2_idx, time consumed:{}".format(end-start))


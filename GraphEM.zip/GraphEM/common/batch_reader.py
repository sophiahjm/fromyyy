#!/usr/bin/env python
# -*- coding: utf-8 -*-
# @Time    : 18/7/15 PM7:20
# @Author  : shaoguang.csg
# @File    : dataset.py


import pandas as pd
import tensorflow as tf
import numpy as np
from utils.logger import logger
from conf.basic_conf import BasicConf


class SimpleCSVReader(object):

    def __init__(self, file_name, selected_cols, batch_size):
        self.data = pd.read_csv(file_name, usecols=selected_cols.split(','), dtype=str).values

        self.num_read = 0
        self.batch_size = batch_size
        self.row_count = self.data.shape[0]

    def get_row_count(self):
        return self.row_count

    def next_batch(self):
        try:
            self.num_read += self.batch_size
            if self.num_read > self.row_count:
                if self.row_count-self.num_read+self.batch_size <= 0:
                    raise EOFError()
                return self.data[self.num_read-self.batch_size:self.row_count,:]
            return self.data[self.num_read-self.batch_size:self.num_read,:]
        except EOFError as e:
            logger.error("next batch iteration finished")


class SimplyTableReader(object):

    def __init__(self, table_name, selected_cols, batch_size, slice_count=1, slice_id=0):

        self.reader = tf.python_io.TableReader(
            table_name,
            selected_cols=selected_cols,
            slice_count=slice_count,
            slice_id=slice_id
        )

        self.num_read = 0
        self.batch_size = batch_size
        self.row_count = self.reader.get_row_count()

    def get_row_count(self):
        return self.row_count

    def next_batch(self):
        try:
            self.num_read += self.batch_size
            if self.num_read > self.row_count:
                if self.row_count-self.num_read+self.batch_size <= 0:
                    raise EOFError()
                return np.array(self.reader.read(self.row_count-self.num_read+self.batch_size))
            return np.array(self.reader.read(self.batch_size))
        except EOFError as e:
            logger.error("next batch iteration finished")


class TableBatchReader(object):

    def __init__(self, filename_list, selected_cols, batch_size, num_epoch, is_shuffle=True, slice_count=1, slice_id=0):
        self.read_op = self._create_read_op(
            filename_list, selected_cols, batch_size, num_epoch,
            is_shuffle, slice_count=slice_count, slice_id=slice_id)
        self._init_reader()

    def _create_read_op(self, filename_list, selected_cols, batch_size,
                        num_epoch, is_shuffle, slice_count=1, slice_id=0):
        with tf.variable_scope('data_reader'):
            filename_queue = tf.train.string_input_producer(
                filename_list,
                num_epochs=num_epoch,
                shuffle=is_shuffle
            )

        if BasicConf.IS_LOCAL:
            reader = tf.TextLineReader(skip_header_lines=1)
        else:
            reader = tf.TableRecordReader(
                csv_delimiter=',',
                selected_cols=selected_cols,
                slice_count=slice_count,
                slice_id=slice_id
            )
        key, value = reader.read_up_to(filename_queue, num_records=batch_size)
        if is_shuffle:
            value = tf.train.shuffle_batch(
                [value],
                batch_size=batch_size,
                capacity=80000,
                enqueue_many=True,
                num_threads=32,
                min_after_dequeue=10000
            )

        cols = tf.decode_csv(
            value,
            record_defaults=self._get_default_record(len(selected_cols.split(','))),
            use_quote_delim=False,
            field_delim=','
        )
        read_op = tf.stack(cols, axis=1)
        return read_op

    def _init_reader(self):
        gpu_options = tf.GPUOptions(allow_growth=True)
        config = tf.ConfigProto(
            gpu_options=gpu_options,
            allow_soft_placement=True,
        )
        self.sess = tf.Session(config=config)
        init_op = [tf.global_variables_initializer(), tf.local_variables_initializer()]
        self.sess.run(init_op)

        self.coord = tf.train.Coordinator()
        self.threads = tf.train.start_queue_runners(sess=self.sess, coord=self.coord)

    def stop(self):
        self.coord.request_stop()
        self.coord.join(self.threads)
        self.sess.close()

    def next_batch(self):
        try:
            lines = self.sess.run(self.read_op)
            return lines
        except tf.errors.OutOfRangeError as e:
            logger.error('next batch iteration finished')
            self.stop()

    @staticmethod
    def _get_default_record(num_field):
        return [['']]*num_field
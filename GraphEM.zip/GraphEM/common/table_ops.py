#!/usr/bin/env python
# -*- coding: utf-8 -*-
# @Time    : 18/7/27 PM2:22
# @Author  : shaoguang.csg
# @File    : table_ops.py

import tensorflow as tf


class WriteEmbedding2Table(object):

    def __init__(self, table_name):
        self._create_writer_op(table_name)
        self._init_writer()

    def _create_writer_op(self, table_name):
        writer = tf.TableRecordWriter(table_name)
        self.id_placeholder = tf.placeholder(dtype=tf.string, name='id_col')
        self.content_placeholder = tf.placeholder(dtype=tf.string, name='content_to_write')
        self.write_to_table = writer.write([0,1], [self.id_placeholder, self.content_placeholder])
        self.close_table = writer.close()

    def _init_writer(self):
        self.session = tf.Session()
        init_op = [tf.global_variables_initializer(), tf.local_variables_initializer()]
        self.session.run(init_op)

    def stop(self):
        self.session.run(self.close_table)

    def write(self, ids, embeddings):
        self.session.run(
            self.write_to_table,
            feed_dict={
                self.id_placeholder: ids,
                self.content_placeholder: embeddings
            }
        )

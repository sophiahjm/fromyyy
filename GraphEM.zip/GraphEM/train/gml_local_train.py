#!/usr/bin/env python
# -*- coding: utf-8 -*-
# @Time    : 18/10/3 PM5:50
# @Author  : shaoguang.csg
# @File    : gml_local_train.py

import tensorflow as tf
import numpy as np
import os

from utils.util import clock, count_param
from utils.logger import logger
from models.graph_metric_learning import GraphMetricLearning
from conf.gml_conf import GMLConf
from utils.sampler import AliasSampling
from common.batch_reader import TableBatchReader
from common.table_ops import WriteEmbedding2Table
from serialization.serialization import node_attr_id_mapping, node_attr_2_idx


def gen_train_batch(dataset, vocab_to_idx, alpha, node_sampler, neighbors, max_neighbor_num):

    def _pad_line(line, max_neighbor_num):
        return line[:max_neighbor_num] if len(line) >= max_neighbor_num else line+[0]*(max_neighbor_num-len(line))

    lines = dataset.next_batch()  # start_node, end_node

    if lines is None:
        return [None]*3

    if GMLConf.IS_LOCAL:
        lines = lines.astype(np.str)

    anchor_nodes_batch = [vocab_to_idx[node] for node in lines[:,0]]
    pos_nodes_batch = [vocab_to_idx[node] for node in lines[:,1]]
    if np.random.rand() > 0.5:
        anchor_nodes_batch, pos_nodes_batch = pos_nodes_batch, anchor_nodes_batch

    neg_nodes_batch = []
    neighbor_nodes_batch = []
    neighbor_nodes_mask = []
    real_neghbor_num = []
    for idx in range(len(anchor_nodes_batch)):
        start_node, end_node = anchor_nodes_batch[idx], pos_nodes_batch[idx]
        tmp = []
        _neighbors = list(neighbors[start_node])  # 当前节点的邻接点
        real_neghbor_num.append(min(len(_neighbors), max_neighbor_num)) #当前节点的真是临界点个数
        _neighbors_mask = [1]*max_neighbor_num if len(_neighbors) > max_neighbor_num else [1]*len(_neighbors)+[0]*(max_neighbor_num-len(_neighbors))
        _neighbors = _pad_line(_neighbors, max_neighbor_num)  # 对neighbors进行pad

        neighbor_nodes_batch.append(_neighbors)
        neighbor_nodes_mask.append(_neighbors_mask)
        neg_exclude_set = neighbors[start_node] if len(neighbors) > 0 else (start_node, end_node) # 负样本的排除节点
        for i in range(alpha):
            while True:
                negative_node = node_sampler.sampling()
                if negative_node not in neg_exclude_set:
                    break
            tmp.append(negative_node)
        neg_nodes_batch.append(tmp)
    return anchor_nodes_batch, pos_nodes_batch, neg_nodes_batch, neighbor_nodes_batch, np.reshape(neighbor_nodes_mask, [len(lines), max_neighbor_num, 1]) , np.reshape(real_neghbor_num, [len(lines), 1])


@clock
def train(conf):
    idx_to_vocab, vocab_to_idx = node_attr_id_mapping(conf)
    node_outin_degree, _, _, neighbors = node_attr_2_idx(conf, vocab_to_idx)
    idx_to_vocab = idx_to_vocab['node']
    node_outin_degree = {k: v[0]+v[1] for k,v in node_outin_degree.items()}
    node_degree = [node_outin_degree[idx_to_vocab[idx]] for idx in range(len(node_outin_degree))]
    node_degree_distribution = node_degree/np.sum(node_degree)
    node_sampler = AliasSampling(prob=node_degree_distribution)

    attr_size = {k: len(v) for k, v in vocab_to_idx.items()}
    logger.info("Attribute size: {}".format(attr_size))

    selected_cols = ','.join([conf.start_node_col_name, conf.end_node_col_name])
    num_epoch = int(conf.max_iteration*conf.batch_size/conf.num_edge)+1
    with tf.Graph().as_default() as graph:
        dataset = TableBatchReader(
            [conf.edge_table],
            selected_cols=selected_cols,
            batch_size=conf.batch_size,
            num_epoch=num_epoch,
            is_shuffle=True
        )

        gml_model = GraphMetricLearning(conf, attr_size)
        gml_model.build_graph()
        gml_model.build_optimizer()
        train_op, loss_op, construct_loss_op, margin_loss_op = gml_model.train_op, gml_model.loss, gml_model.construct_loss, gml_model.margin_loss

        summary_op = tf.summary.merge_all()
        summary_writer = tf.summary.FileWriter(os.path.join(conf.checkpoint_dir, 'summary_log'), graph=graph)
        saver = tf.train.Saver()

        config = tf.ConfigProto(
            gpu_options=tf.GPUOptions(allow_growth=True),
            allow_soft_placement=True,
        )
        session = tf.Session(config=config)
        session.run(tf.local_variables_initializer())
        session.run(tf.global_variables_initializer())

        count_param()

        vocab_to_idx = vocab_to_idx['node']
        for step in range(conf.max_iteration):
            anchor_nodes, pos_nodes, neg_nodes, anchor_neighbor_nodes, neighbor_nodes_mask, real_neighbor_num = \
                gen_train_batch(dataset, vocab_to_idx, conf.alpha, node_sampler, neighbors, conf.max_neighbor)

            if anchor_nodes is None:
                break

            feed_dict = {
                gml_model.anchor_nodes:anchor_nodes,
                gml_model.pos_nodes:pos_nodes,
                gml_model.neg_nodes:neg_nodes,
                gml_model.anchor_neighbor_nodes:anchor_neighbor_nodes,
                gml_model.anchor_neighbor_mask:neighbor_nodes_mask,
                gml_model.real_neighbor_num:real_neighbor_num
            }

            [_, loss, construct_loss, margin_loss] = session.run([train_op, loss_op, construct_loss_op, margin_loss_op], feed_dict=feed_dict)
            if step % 5 == 0:
                logger.info("step {}, total_loss {}, construct_loss {}, margin_loss {}".format(step, loss, construct_loss, margin_loss))

            if step % 100 == 0:
                summary_str = session.run(summary_op, feed_dict=feed_dict)
                summary_writer.add_summary(summary_str, step)

            if step % 10000 == 0:
                saver.save(session, conf.checkpoint_dir)

        write_embedding_to_table(session, conf.embedding_result_table, gml_model, idx_to_vocab)


#  和line里面不一样，不对边进行采样，而是对每一条边都过k次，对每一条边，进行中止节点的负采样，对节点进行负采样时，要判断负采样出来的节点是不是和出发节点
#  构成一条边，所以要将边的表全部加载进去；此种做法最笨了，另一种做法就是在节点的属性表里面添加一列，表示该节点的邻接点，但是限制邻接点的个数，最多放1w个，否则表太大


@clock
def write_embedding_to_table(session, table_name, model, idx_to_vocab):
    cnt = 0
    batch_ids, batch_nodes = [], []
    writer = WriteEmbedding2Table(table_name)
    for idx, node_id in idx_to_vocab.items():
        if len(batch_ids) < conf.batch_size-1:
            batch_ids.append(idx)
            batch_nodes.append(node_id)
            continue
        batch_ids.append(idx)
        batch_nodes.append(node_id)
#        embeddings = get_fc1_embeddings(session, model, batch_ids) # 此处更换不同方法产出的embedding结果
        embeddings = get_embeddings(session, model, batch_ids)
        embeddings = [','.join(_) for _ in embeddings.astype(np.str)]
        writer.write(batch_nodes, embeddings)  # node_id, embedding
        cnt += len(embeddings)
        if cnt % (conf.batch_size*100) == 0:
            logger.info("write {} nodes to table".format(cnt))
        batch_ids, batch_nodes = [], []

    if len(batch_ids) > 0:
#        embeddings = get_fc1_embeddings(session, model, batch_ids) # 此处更换不同方法产出的embedding结果
        embeddings = get_embeddings(session, model, batch_ids)
        embeddings = [','.join(_) for _ in embeddings.astype(np.str)]
        writer.write(batch_nodes, embeddings)
        cnt += len(embeddings)
    writer.stop()
    logger.info("Totally write {} nodes to table".format(cnt))


def get_embeddings(sess, model, ids):
    embeddings = model.get_embedding(model.nodes_embedding, ids)
    embeddings = sess.run(embeddings)
    return embeddings


def get_fc1_embeddings(sess, model, ids):
    feed_dict = {model.nodes:ids}
    output_embed = sess.run(model.nodes_output_embed, feed_dict=feed_dict)
    return output_embed


if __name__ == '__main__':
    conf = GMLConf()
    train(conf)

#!/usr/bin/env python
# -*- coding: utf-8 -*-
# @Time    : 17/12/7 AM10:42
# @Author  : shaoguang.csg
# @File    : parse_conf.py

import yaml
import tensorflow as tf
import os.path as path

from utils.system_op import object_to_str
from utils.logger import logger
from task.task import Task
from task.multi_task import Multitask


FLAGS = tf.app.flags.FLAGS
tf.app.flags.DEFINE_string('model_conf_file', '../conf/model_conf.yaml', 'Path to the model config yaml file')
tf.app.flags.DEFINE_string('data_conf_file', '../conf/data_conf.yaml', 'Path to the data config yaml file')


def singleton(cls):
    _instances = {}

    def _singleton(*args, **kwargs):
        if cls not in _instances:
            _instances[cls] = cls(*args, **kwargs)
        return _instances[cls]
    return _singleton


def check_file_exists(filename):
    if not path.exists(filename):
        raise Exception("%s does not exists" % filename)


@singleton
class DataConf(object):

    def __init__(self):
        with open(FLAGS.data_conf_file) as data_conf_file:
            data_conf = yaml.load(data_conf_file)

        self.train_file = data_conf.get('train_file', None)
        self.evaluate_file = data_conf.get('evaluate_file', None)
        self.test_file = data_conf.get('test_file', None)
        self.multi_hot_columns = data_conf.get('multi_hot_columns', {})
        self.multi_category_columns = data_conf.get('multi_category_columns',None)
        self.continuous_columns = data_conf.get('continuous_columns', None)
        self.crossed_columns = data_conf.get('crossed_columns', None)
        self.bucketized_columns = data_conf.get('bucketized_columns', None)
        self.embeding_columns = data_conf.get('embeding_columns', None)

        self._check_param()

    def _check_param(self):
        if self.train_file is None and self.test_file is None:
            logger.error("train_file and test_file can not be None at the same time")
            raise ValueError

        if self.train_file is not None:
            check_file_exists(self.train_file)
        if self.evaluate_file is not None:
            check_file_exists(self.evaluate_file)
        if self.test_file is not None:
            check_file_exists(self.test_file)

        if self.multi_hot_columns is not None:
            assert isinstance(self.multi_hot_columns, dict), "type of multi_hot_columns must be <dict>"

        if self.multi_category_columns is not None:
            assert len(self.multi_category_columns) > 0
        if self.continuous_columns is not None:
            assert len(self.continuous_columns) > 0
        if self.crossed_columns is not None:
            assert isinstance(self.crossed_columns, list)
            for _ in self.crossed_columns:
                assert isinstance(_, list)
                assert isinstance(_[-1], int), 'last dimension of crossed features must be the size of crossed result '
                assert len(_)-1 >= 2
        if self.bucketized_columns is not None:
            assert isinstance(self.bucketized_columns, dict)
            for _ in self.bucketized_columns:
                assert isinstance(self.bucketized_columns[_], list)
        if self.embeding_columns is not None:
            assert isinstance(self.embeding_columns, list)

    def __str__(self):
        return str(object_to_str(self))


@singleton
class ModelConf(object):
    def __init__(self):
        with open(FLAGS.model_conf_file) as model_conf_file:
            model_conf = yaml.load(model_conf_file)

        self.model_dir = model_conf.get('model_dir', '/tmp/')
        self.log_dir = model_conf.get('log_dir', '/tmp/')
        self.append_cols = model_conf.get('append_cols', [])

        self.base_lr = model_conf.get('base_lr', 0.01)
        self.lr_policy = model_conf.get('lr_policy', 'fixed')
        self.step_size = model_conf.get('step_size', 10000)
        self.dropout_ratio = model_conf.get('dropout_ratio', 0.0)
        self.embedding_dimension = model_conf.get('embedding_dimension', 16)
        self.alpha = model_conf.get('alpha', 0.0)
        self.beta = model_conf.get('beta', 0.05)
        self.early_stopping_interval = model_conf.get('early_stopping_interval', 2000)
        self.evaluate_interval = model_conf.get('evaluate_interval', 5000)
        self.save_checkpoint_interval = model_conf.get('save_checkpoint_interval', 10000)
        self.num_cpu_core = model_conf.get('num_cpu_core', 2)
        self.num_threads_per_core = model_conf.get('num_threads_per_core', 4)

        self.multi_tasks = self.parse_task(model_conf.get('tasks', None))

        self._check_param()

    def parse_task(self, tasks:dict):
        if tasks is None:
            logger.error("MTL structure must not be None")
            raise TypeError

        assert len(tasks['common_features']) > 0, "Length of common features must be greater than 0"
        assert len(tasks['common_hidden_units']) > 0, "Length of common hidden units must be greater than 0"

        multi_tasks = Multitask()
        multi_tasks.common_features = tasks['common_features']
        multi_tasks.common_hidden_units = tasks['common_hidden_units']
        tasks.pop('common_features')
        tasks.pop('common_hidden_units')

        for task_name in tasks:
            task = Task(task_name)
            task.features = tasks[task_name]['features']
            task.target = tasks[task_name]['target']
            task.task_type = tasks[task_name]['task_type']
            if task.task_type == 'classification':
                task.num_class = tasks[task_name].get('num_class', None)
                assert task.num_class is not None and task.num_class > 1
            task.hidden_units = tasks[task_name].get('hidden_units', [])
            task.dropout_ratio = tasks[task_name].get('dropout_ratio', self.dropout_ratio)
            multi_tasks.add_task(task)
        return multi_tasks

    def _check_param(self):
        if self.model_dir is not None:
            check_file_exists(self.model_dir)
        if self.log_dir is not None:
            check_file_exists(self.log_dir)

        assert self.base_lr > 0, 'learning rate must be positive'
        assert self.lr_policy in ('fixed', 'step'), "valid lr policy:{'fixed', 'step'}"
        assert self.step_size > 0
        assert self.dropout_ratio >= 0 and self.dropout_ratio <= 1
        assert self.alpha >= 0
        assert self.beta >= 0
        assert self.embedding_dimension > 1
        assert self.early_stopping_interval > 0
        assert self.evaluate_interval > 0
        assert self.save_checkpoint_interval > 0

    def __str__(self):
        return str(object_to_str(self))

if __name__ == '__main__':
    data_conf = DataConf()
    print(data_conf)